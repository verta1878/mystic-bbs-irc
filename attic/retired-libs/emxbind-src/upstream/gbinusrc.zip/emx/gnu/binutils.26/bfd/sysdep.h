#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <string.h>
#include <sys/file.h>

#ifndef EMX
#define EMX
#endif

#define	HAVE_STRERROR

#define	POSIX_UTIME
#define NO_FCNTL

#define HOST_PAGE_SIZE		0x1000
#define HOST_SEGMENT_SIZE	0x10000
#define HOST_MACHINE_ARCH	bfd_arch_emx
#define HOST_TEXT_START_ADDR	0x10000
#define HOST_STACK_END_ADDR	0x80000000

#define N_HEADER_IN_TEXT(x) 0

#define N_TXTOFF(x)	\
    (N_MAGIC(x) != ZMAGIC ? EXEC_BYTES_SIZE : /* object file or NMAGIC */\
     N_SHARED_LIB(x) ? 0 : \
     N_HEADER_IN_TEXT(x) ?	\
	    EXEC_BYTES_SIZE :			/* no padding */\
            0x400 + (x).emx_add \
    )

#define N_DATOFF(x) (N_TXTOFF(x) + N_TXTSIZE(x))

/* EXACT TYPES */
 typedef char int8e_type;
 typedef unsigned char uint8e_type;
 typedef short int16e_type;
 typedef unsigned short uint16e_type;
 typedef int int32e_type;
 typedef unsigned int uint32e_type;
 
 /* CORRECT SIZE OR GREATER */
 typedef char int8_type;
 typedef unsigned char uint8_type;
 typedef short int16_type;
 typedef unsigned short uint16_type;
 typedef int int32_type;
 typedef unsigned int uint32_type;

#include "fopen-bin.h"

#define NO_CORE_COMMAND
