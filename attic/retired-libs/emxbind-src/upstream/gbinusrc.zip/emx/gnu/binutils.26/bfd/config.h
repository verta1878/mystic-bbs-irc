/* config.h */

#define USE_BINARY_FOPEN
#define HAVE_GETPAGESIZE
#define HAVE_FCNTL_H
#define HAVE_STDDEF_H
#define HAVE_STDLIB_H
#define HAVE_STRING_H
#define HAVE_TIME_H
#define HAVE_UNISTD_H
#define HAVE_TIME_T_IN_TIME_H
#define HAVE_TIME_T_IN_TYPES_H
#define HAVE_SBRK

extern char *_getname();
extern char *strdup();
