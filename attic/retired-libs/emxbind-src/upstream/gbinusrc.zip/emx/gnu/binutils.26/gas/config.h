#include <stdlib.h>

#define FOPEN_WB
#define USE_STDARG
#define HAVE_SBRK

#define TARGET_CPU              "i386"
#define TARGET_ALIAS            "i386"
#define TARGET_CANONICAL        "i386"
#define GAS_VERSION             "2.6"
