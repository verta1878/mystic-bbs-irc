/* te-emx.h */

#define TE_EMX  1

#define LOCAL_LABELS_DOLLAR     1

#define TARGET_FORMAT "a.out-emx"

#include "obj-format.h"

/* We define this to get same output as with gas 1.38 (for comparing
   .o files). */

#define REVERSE_SORT_RELOCS     1
