/* strtold.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <emx/float.h>

long double _strtold (const char *string, char **end_ptr)
{
  const char *end;
  long double z;

  end = __atod (&z, string, LDBL_MIN_EXP, LDBL_MAX_EXP, 16383,
                LDBL_MANT_DIG, DECIMAL_DIG, LDBL_MAX_10_EXP, -4951);
  if (end_ptr != NULL)
    *end_ptr = (char *)end;
  return z;
}
