/* strtof.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <emx/float.h>

float _strtof (const char *string, char **end_ptr)
{
  const char *end;
  long double z;

  end = __atod (&z, string, FLT_MIN_EXP, FLT_MAX_EXP, 127,
                FLT_MANT_DIG, DECIMAL_DIG, FLT_MAX_10_EXP, -45);
  if (end_ptr != NULL)
    *end_ptr = (char *)end;
  return (float)z;
}
