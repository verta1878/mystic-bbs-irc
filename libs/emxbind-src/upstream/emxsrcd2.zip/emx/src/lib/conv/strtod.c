/* strtod.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <emx/float.h>

double strtod (const char *string, char **end_ptr)
{
  const char *end;
  long double z;

  end = __atod (&z, string, DBL_MIN_EXP, DBL_MAX_EXP, 1023,
                DBL_MANT_DIG, DECIMAL_DIG, DBL_MAX_10_EXP, -324);
  if (end_ptr != NULL)
    *end_ptr = (char *)end;
  return (double)z;
}
