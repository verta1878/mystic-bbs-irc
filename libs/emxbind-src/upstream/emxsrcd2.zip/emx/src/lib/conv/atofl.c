/* atofl.c (emx+gcc) -- Copyright (c) 1993-1995 by Eberhard Mattes */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long double _atofl (const char *s)
{
  return _strtold (s, NULL);
}
