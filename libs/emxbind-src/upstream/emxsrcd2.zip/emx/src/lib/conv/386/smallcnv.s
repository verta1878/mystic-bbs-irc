/ smallcnv.s (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes

        .stabs  "___atod", 11, 0, 0, 0
        .stabs  "___small_atod", 1, 0, 0, 0

        .stabs  "___dtoa", 11, 0, 0, 0
        .stabs  "___small_dtoa", 1, 0, 0, 0
