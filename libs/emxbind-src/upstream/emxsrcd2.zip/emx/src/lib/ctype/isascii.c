/* isascii.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int _isascii (int c)
{
  return isascii (c);
}
