/* _toupper.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int _toupper (int c)
{
  return c - 'a' + 'A';
}
