/* toascii.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int _toascii (int c)
{
  return toascii (c);
}
