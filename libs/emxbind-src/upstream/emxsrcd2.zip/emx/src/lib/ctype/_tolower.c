/* _tolower.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int _tolower (int c)
{
  return c + 'a' - 'A';
}
