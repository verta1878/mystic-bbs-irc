/* isalpha.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int (isalpha) (int c)
{
  return isalpha (c);
}
