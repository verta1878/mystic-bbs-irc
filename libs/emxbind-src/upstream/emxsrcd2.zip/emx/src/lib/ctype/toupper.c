/* toupper.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <ctype.h>

int toupper (int c)
{
  if (c >= 'a' && c <= 'z')
    return c - 'a' + 'A';
  else
    return c;
}
