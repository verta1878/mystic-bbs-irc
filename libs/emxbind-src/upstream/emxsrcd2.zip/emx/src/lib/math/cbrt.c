/* cbrt.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <math.h>

double _cbrt (double x)
{
  if (x >= 0)
    return pow (x, 1.0 / 3.0);
  else
    return -pow (-x, 1.0 / 3.0);
}
