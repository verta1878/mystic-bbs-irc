/ atan.s (emx+gcc) -- Copyright (c) 1991-1996 by Eberhard Mattes

#include <emx/asm386.h>

#define FUNC    MATHSUFFIX1(atan)

        .globl  LABEL(FUNC)

        .text

        ALIGN

/ double atan (double x)

#define x       4(%esp)

LABEL(FUNC):
        PROFILE_NOFRAME
        FLD     x                       /* x */
        fldl    __const_ONE
        fpatan
        EPILOGUE(FUNC)
