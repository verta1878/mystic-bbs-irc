/* cbrtl.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <math.h>

long double _cbrtl (long double x)
{
  if (x >= 0)
    return _powl (x, 1.0 / 3.0);
  else
    return -_powl (-x, 1.0 / 3.0);
}
