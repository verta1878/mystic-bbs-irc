/ atan2.s (emx+gcc) -- Copyright (c) 1991-1996 by Eberhard Mattes

#include <emx/asm386.h>

#define FUNC    MATHSUFFIX1(atan2)

        .globl  LABEL(FUNC)

        .text

        ALIGN

/ double atan2 (double y, double x)

#define y        4(%esp)
#if defined (LONG_DOUBLE)
#define x       16(%esp)
#else
#define x       12(%esp)
#endif

LABEL(FUNC):
        PROFILE_NOFRAME
        FLD     y                       /* y */
        FLD     x                       /* x */
        fpatan
        EPILOGUE(FUNC)
