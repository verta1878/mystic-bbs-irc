/ ceil.s (emx+gcc) -- Copyright (c) 1991-1996 by Eberhard Mattes

#include <emx/asm386.h>

#define FUNC    MATHSUFFIX1(ceil)

        .globl  LABEL(FUNC)

        .text

        ALIGN

/ double ceil (double x)

#define cw1       0(%esp)
#define cw2       2(%esp)
/define ret_addr  4(%esp)
#define x         8(%esp)

LABEL(FUNC):
        PROFILE_NOFRAME
        subl    $4, %esp
        fstcww  cw1
        movw    cw1, %ax
        andw    $0xf3ff, %ax
        orw     $0x0800, %ax            /* round up towards +inf */
        movw    %ax, cw2
        fldcww  cw2
        FLD     x                       /* x */
        frndint
        fldcww  cw1
        addl    $4, %esp
        EPILOGUE(FUNC)
