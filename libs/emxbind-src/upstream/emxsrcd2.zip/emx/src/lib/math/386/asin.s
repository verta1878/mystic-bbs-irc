/ asin.s (emx+gcc) -- Copyright (c) 1991-1996 by Eberhard Mattes

#include <emx/asm386.h>

#define FUNC    MATHSUFFIX1(asin)

        .globl  LABEL(FUNC)

        .text

        ALIGN

/ double asin (double x)

/ asin(x) = atan (x / sqrt (1-x*x))

#define x       4(%esp)

LABEL(FUNC):
        PROFILE_NOFRAME
        FLD     x                       /* x */
        fld     %st
        fld     %st
        fmulp
        fsubrl  __const_ONE
        fsqrt
        fdivrp
        fldl    __const_ONE
        fpatan
        _xam
        j_nan   Lerror
Lreturn:EPILOGUE(FUNC)

        ALIGN
Lerror: SET_ERRNO_CONST($EDOM)
        jmp     Lreturn
