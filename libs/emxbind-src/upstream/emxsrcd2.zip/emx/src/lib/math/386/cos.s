/ cos.s (emx+gcc) -- Copyright (c) 1992-1993 by Steffen Haecker
/                    Modified 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

#define FUNC    MATHSUFFIX1(cos)

        .globl  LABEL(FUNC)

        .text

        ALIGN

/ double cos (double x)

#define x       4(%esp)

LABEL(FUNC):
        PROFILE_NOFRAME
        FLD     x                       /* x */
        fcos                            /* cos(x) */
        fstsww  %ax
        testb   $0x04, %ah                              
        jnz     Llarge                  /* C2 != 0 ? */
Lreturn:EPILOGUE(FUNC)

        ALIGN
Llarge: fldl    __const_ONE             /* cos(large):=1 */
        fstp    %st(1)
        jmp     Lreturn
