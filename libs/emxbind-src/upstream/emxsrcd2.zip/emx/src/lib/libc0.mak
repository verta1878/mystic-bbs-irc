#
# /emx/src/lib/libc0.mak
#
.INCLUDE: /emx/src/lib/lib0.mak

.IF $(OMF)
DSTLIB=/emx/lib/$(LIBNAME).lib
.ELSE
DSTLIB=/emx/lib/$(LIBNAME).a
.END
LIBC_CCFLAGS=-I.. $(MORE_LIBC_CCFLAGS)

.PHONY: default clean lib-st lib-st-p lib-mt dstlib local \
        lib-st-2 lib-st-p-2 lib-mt-2

.SOURCE.c: ../$(CPU)
.SOURCE.h: ../$(CPU)
.SOURCE.s: ../$(CPU)

.SOURCE.c: ..
.SOURCE.h: ..
.SOURCE.s: ..

default: lib-st lib-mt lib-st-p

lib-st: local lib-st-2
lib-st-p: local lib-st-p-2
lib-mt: local lib-mt-2

lib-st-2 .SETDIR=st_$(CPU):
	$(MAKE) -f ../makefile dstlib $(PASSDOWN) LIBNAME=st/$(LIBBASE) MT_CCFLAGS=

lib-st-p-2 .SETDIR=st_p_$(CPU):
	$(MAKE) -f ../makefile dstlib $(PASSDOWN) LIBNAME=st/$(LIBBASE)_p MT_CCFLAGS=-pg

lib-mt-2 .SETDIR=mt_$(CPU):
	$(MAKE) -f ../makefile dstlib $(PASSDOWN) LIBNAME=mt/$(LIBBASE) MT_CCFLAGS=-Zmt

dstlib: $(DSTLIB)

.IF $(OMF)
clean:
	-del st_$(CPU)\*.obj $(DELOPT)
	-del mt_$(CPU)\*.obj $(DELOPT)
	-del st_p_$(CPU)\*.obj $(DELOPT)
.ELSE
clean:
	-del st_$(CPU)\*.o $(DELOPT)
	-del mt_$(CPU)\*.o $(DELOPT)
	-del st_p_$(CPU)\*.o $(DELOPT)
.END
