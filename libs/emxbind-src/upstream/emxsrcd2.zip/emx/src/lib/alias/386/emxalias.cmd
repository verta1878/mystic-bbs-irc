@echo .stabs "_%1", 11, 0, 0, 0; .stabs "_%2", 1, 0, 0, 0|as -o %3
