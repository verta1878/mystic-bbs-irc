/ fixusfdi.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl ___fixunssfdi

        .text

	ALIGN

/ ldexp (1.0, 63)

LC2:    .long   0x00000000
        .long   0x43e00000

#define tmp_lo       -12(%ebp)
#define tmp_hi        -8(%ebp)
#define cw1           -4(%ebp)
#define cw2           -2(%ebp)
/define saved_ebp      0(%ebp)
/define ret_addr       4(%ebp)
#define x              8(%ebp)

___fixunssfdi:
        pushl   %ebp
        movl    %esp, %ebp
        PROFILE_FRAME
        subl    $12, %esp
        fstcw   cw1
        movw    cw1, %ax
        orw     $0x0c00, %ax            /* truncate towards zero */
        movw    %ax, cw2
        fldcw   cw2
        flds    x
        fcoml   LC2
        fstsww  %ax
        sahf
        jb      1f
        fsubl   LC2
        fistpq  tmp_lo
        addl    $0x80000000, tmp_hi
        jmp     2f

        ALIGN
1:      fistpq  tmp_lo
2:      movl    tmp_lo, %eax
        movl    tmp_hi, %edx
        fldcw   cw1
        leave
        EPILOGUE(__fixunssfdi)
