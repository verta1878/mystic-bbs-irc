/ ehfinit.s (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___eh_frame_init
        .globl  ___eh_frame_term
        .weak   ___eh_frame_init2
        .weak   ___eh_frame_term2

        .text
___eh_frame_init:
        lea     ___eh_frame_init2, %eax
        testl   %eax, %eax
        jnz     ___eh_frame_init2
        ret

        ALIGN
___eh_frame_term:
        lea     ___eh_frame_term2, %eax
        testl   %eax, %eax
        jnz     ___eh_frame_term2
        ret
