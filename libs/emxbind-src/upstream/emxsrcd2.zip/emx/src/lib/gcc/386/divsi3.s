/ divsi3.s (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___divsi3

        ALIGN

___divsi3:
        PROFILE_NOFRAME
        movl    1*4(%esp), %eax
        cltd
        idivl   2*4(%esp)
        EPILOGUE(__divsi3)
