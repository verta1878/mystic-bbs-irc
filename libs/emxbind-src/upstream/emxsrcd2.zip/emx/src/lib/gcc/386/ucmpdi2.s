/ ucmpdi2.s (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___ucmpdi2

        .text

        ALIGN

/ int __ucmpdi2 (unsigned long long x, unsigned long long y)

/define ret_addr   0(%esp)
#define x_lo       4(%esp)
#define x_hi       8(%esp)
#define y_lo      12(%esp)
#define y_hi      16(%esp)

___ucmpdi2:
        PROFILE_NOFRAME
        xorl    %eax, %eax              /* 0: x < y */
        movl    x_hi, %edx
        cmpl    y_hi, %edx
        jb      9f
        movb    $2, %al                 /* 2: x > y */
        ja      9f
        movl    x_lo, %edx
        cmpl    y_lo, %edx
        ja      9f                      /* 2: x > y */
        movb    $0, %al
        jb      9f                      /* 0: x < y */
        movb    $1, %al                 /* 1: x = y */
        ALIGN
9:      EPILOGUE(__ucmpdi2)
