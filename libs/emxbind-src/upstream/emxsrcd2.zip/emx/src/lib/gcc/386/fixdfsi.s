/ fixdfsi.s (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___fixdfsi

        .text

        ALIGN

#define tmp           -8(%ebp)
#define cw1           -4(%ebp)
#define cw2           -2(%ebp)
/define saved_ebp      0(%ebp)
/define ret_addr       4(%ebp)
#define x              8(%ebp)

___fixdfsi:
        pushl   %ebp
        movl    %esp, %ebp
        PROFILE_FRAME
        subl    $8, %esp
        fstcw   cw1
        movw    cw1, %ax
        orw     $0x0c00, %ax            /* truncate towards zero */
        movw    %ax, cw2
        fldcw   cw2
        fldl    x
        fistpl  tmp
        fldcw   cw1
        movl    tmp, %eax
        leave
        EPILOGUE(__fixdfsi)
