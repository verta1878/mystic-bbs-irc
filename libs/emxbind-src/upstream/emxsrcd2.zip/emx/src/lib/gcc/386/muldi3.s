/ muldi3.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___muldi3

        .text

        ALIGN

/ long long __muldi3 (long long x, long long y)

#define tmp_lo    -8(%ebp)
#define tmp_hi    -4(%ebp)
/define saved_ebp  0(%ebp)
/define ret_addr   4(%ebp)
#define x_lo       8(%ebp)
#define x_hi      12(%ebp)
#define y_lo      16(%ebp)
#define y_hi      20(%ebp)

___muldi3:
        pushl   %ebp
        movl    %esp, %ebp
        PROFILE_FRAME
        subl    $8, %esp
        movl    x_lo, %eax
        mull    y_lo
        movl    %eax, tmp_lo
        movl    %edx, tmp_hi
        movl    x_lo, %eax
        mull    y_hi
        addl    %eax, tmp_hi
        movl    y_lo, %eax
        mull    x_hi
        addl    tmp_hi, %eax
        movl    %eax, %edx
        movl    tmp_lo, %eax
        leave
        EPILOGUE(__muldi3)
