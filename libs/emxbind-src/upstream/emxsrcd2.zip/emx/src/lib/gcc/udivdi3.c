/* udivdi3.c (emx+gcc) -- Copyright (c) 1992-1995 by Eberhard Mattes */

#include <stdlib.h>

unsigned long long __udivdi3 (unsigned long long x, unsigned long long y)
{
  return _ulldiv (x, y).quot;
}
