/* main.c (emx+gcc) -- Copyright (c) 1992-1994 by Eberhard Mattes */
/*                     Copyright (c) 1992-1994 by Kai Uwe Rommel */

#include <stdlib.h>

extern void __ctordtorInit (void);
extern void __ctordtorTerm (void);

/* This module is always statically linked in order to get a
   statically linked __ctordtorInit() which uses the __CTOR_LIST__ and
   __DTOR_LIST__ of the executable. */

void __main (void)
{
  __ctordtorInit ();
  atexit (__ctordtorTerm);
}
