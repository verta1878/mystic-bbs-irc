/* purevirt.c */

#include <unistd.h>
#include <io.h>

void __pure_virtual (void)
{
  static char msg[] = "Pure virtual method called\n";

  _write (STDERR_FILENO, msg, sizeof (msg) - 1);
  _exit (255);
}
