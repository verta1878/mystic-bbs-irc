/* bounds.c (emx+gcc) */

int __bounds_checking_on = 0;
