/* dummy.c */

void __dummy (void)
{
}
