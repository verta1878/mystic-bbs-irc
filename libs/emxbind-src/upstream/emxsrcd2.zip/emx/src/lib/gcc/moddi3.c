/* moddi3.c (emx+gcc) -- Copyright (c) 1992-1994 by Eberhard Mattes */

#include <stdlib.h>

long long __moddi3 (long long x, long long y)
{
  return _lldiv (x, y).rem;
}
