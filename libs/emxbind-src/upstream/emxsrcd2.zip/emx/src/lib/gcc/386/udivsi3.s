/ udivsi3.s (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes

#include <emx/asm386.h>

        .globl  ___udivsi3

        ALIGN

___udivsi3:
        PROFILE_NOFRAME
        movl    1*4(%esp), %eax
        xorl    %edx, %edx
        divl    2*4(%esp)
        EPILOGUE(__udivsi3)
