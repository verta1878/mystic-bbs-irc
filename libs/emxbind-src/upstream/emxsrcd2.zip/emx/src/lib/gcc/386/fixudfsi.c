/* fixudfsi.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdio.h>
#include <math.h>

long __fixunsdfsi (double a)
{
  if (a < 2147483648.0)
    return (long)a;
  else
    return ((long)(a - 2147483648.0)) + (long)0x80000000;
}
