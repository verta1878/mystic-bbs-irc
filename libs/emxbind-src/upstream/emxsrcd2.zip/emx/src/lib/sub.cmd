/* sub.cmd */

parse arg prog
'@echo off'
call sub1 'alias'
call sub1 'app'
call sub1 'cdll'
call sub1 'conv'
call sub1 'ctype'
call sub1 'dllnrt'
call sub1 'dllrt'
call sub1 'dllso'
call sub1 'emx_386'
call sub1 'emxload'
call sub1 'end'
call sub1 'gcc'
call sub1 'graph'
call sub1 'io'
call sub1 'locale'
call sub1 'malloc'
call sub1 'malloc1'
call sub1 'math'
call sub1 'mbyte'
call sub1 'misc'
call sub1 'moddef'
call sub1 'nls'
call sub1 'omflib'
call sub1 'os2_386'
call sub1 'process'
call sub1 'socket'
call sub1 'static'
call sub1 'startup'
call sub1 'str'
call sub1 'sys'
call sub1 'termios'
call sub1 'time'
call sub1 'tmalloc'
call sub1 'video'
exit

sub1:
  parse arg dir
  'cd '||dir
  say dir
  prog
  'cd ..'
  return
