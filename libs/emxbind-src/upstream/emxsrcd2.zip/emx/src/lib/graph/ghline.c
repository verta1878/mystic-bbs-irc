/* ghline.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#include "graph2.h"

void _no_hline (unsigned x, unsigned y, unsigned n, int color)
{
}


static void (*_j_hline) (unsigned x, unsigned y, unsigned n, int color)
     = _no_hline;


void g_hline (int y, int x0, int x1, int color)
{
  int f, n;

  if (y >= _g_clipy0 && y <= _g_clipy1)
    {
      f = 1;
      if (x0 < _g_clipx0)
        {
          x0 = _g_clipx0; --f;
        }
      if (x1 < _g_clipx0)
        {
          if (f == 0)
            return;
          x1 = _g_clipx0;
        }
      f = 1;
      if (x0 > _g_clipx1)
        {
          x0 = _g_clipx1; --f;
        }
      if (x1 > _g_clipx1)
        {
          if (f == 0)
            return;
          x1 = _g_clipx1;
        }
      if (x0 <= x1)
        n = x1 - x0 + 1;
      else
        {
          n = x0 - x1 + 1;
          x0 = x1;
        }
      _j_hline (x0, y, n, color);
    }
}


GPRIM_DEF (hline);
GPRIM_ALL (hline);
