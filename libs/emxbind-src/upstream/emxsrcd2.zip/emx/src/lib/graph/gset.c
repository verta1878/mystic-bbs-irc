/* gset.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#include "graph2.h"

static void _no_set (unsigned x, unsigned y, int color)
{
}


static void (*_j_set) (unsigned x, unsigned y, int color) = _no_set;

void g_set (int x, int y, int color)
{
  _j_set (x, y, color);
}


GPRIM_DEF (set);
GPRIM_ALL (set);
