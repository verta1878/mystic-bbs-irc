/* gwaitv.c (emx+gcc) -- Copyright (c) 1987-1998 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#define INCL_VIO
#include <os2emx.h>
#include "graph2.h"
#include <sys/hw.h>

static int port_flag = 0;

void g_waitv (void)
{
  if (port_flag == 0)
    {
      if (_portaccess (0x3da, 0x3da) == 0)
        port_flag = 1;
      else
        port_flag = -1;
    }
  if (port_flag == 1)
    {
     GLOCK;
     _wait01 (0x3da, 0x08);
      GUNLOCK;
    }
}
