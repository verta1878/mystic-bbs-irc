/* vglget.c (emx+gcc) -- Copyright (c) 1987-1995 by Eberhard Mattes */

#include <stdlib.h>
#include "graph2.h"


int _vgl_get (unsigned x, unsigned y)
{
  int ret;

  if (x >= _g_clipx0 && x <= _g_clipx1 && y >= _g_clipy0 && y <= _g_clipy1)
    {
      GLOCK;
      ret = _g_mem[x + y * _g_xsize];
      GUNLOCK;
      return ret;
    }
  else
    return -1;
}
