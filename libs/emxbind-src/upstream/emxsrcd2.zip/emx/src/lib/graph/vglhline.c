/* vglhline.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include <memory.h>
#include "graph2.h"


void _vgl_hline (unsigned x, unsigned y, unsigned n, int color)
{
  GLOCK;
  memset (_g_mem + y * 320 + x, color, n);
  GUNLOCK;
}
