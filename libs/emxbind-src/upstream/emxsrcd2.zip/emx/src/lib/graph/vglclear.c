/* vglclear.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <memory.h>
#include "graph2.h"

void _vgl_clear (int color)
{
  memset (_g_mem, color, _g_xsize * _g_ysize);
}
