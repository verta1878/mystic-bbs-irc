/* vglvline.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include "graph2.h"


void _vgl_vline (unsigned x, unsigned y, unsigned n, int color)
{
  volatile unsigned char *p;

  GLOCK;
  p = _g_mem + x + 320 * y;
  while (n > 0)
    {
      *p = (unsigned char)color;
      p += 320;
      --n;
    }
  GUNLOCK;
}
