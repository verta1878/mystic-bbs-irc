/* gclear.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#include "graph2.h"


static void _no_clear (int color)
{
}


static void (*_j_clear) (int color) = _no_clear;

void g_clear (int color)
{
  GLOCK;
  _j_clear (color);
  GUNLOCK;
}


GPRIM_DEF (clear);
GPRIM_ALL (clear);
