/* gget.c (emx+gcc) -- Copyright (c) 1987-1995 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#include "graph2.h"

static int _no_get (unsigned x, unsigned y)
{
  return -1;
}


static int (*_j_get) (unsigned x, unsigned y) = _no_get;

int g_get (int x, int y)
{
  return _j_get (x, y);
}


GPRIM_DEF (get);
GPRIM_ALL (get);
