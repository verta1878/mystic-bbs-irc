/* ega.h (emx+gcc) -- Copyright (c) 1994 by Steffen Haecker */

extern unsigned short _g_out[];

#define MASK(X) \
  _outp8 (0x3cf, X)

#define OUT1(X) \
  _outp16 (0x3ce, X)

#define OUT2(X,Y) \
  _g_out[0] = X; \
  _g_out[1] = Y; \
  _outps16 (0x3ce, _g_out, 2)

#define OUT3(X,Y,Z) \
  _g_out[0] = X; \
  _g_out[1] = Y; \
  _g_out[2] = Z; \
  _outps16 (0x3ce, _g_out, 3)

#define BITPLANE(X) \
  _outp8 (0x3cf, X)
