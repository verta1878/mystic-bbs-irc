/* vglset.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include "graph2.h"


void _vgl_set (unsigned x, unsigned y, int color)
{
  if (x >= _g_clipx0 && x <= _g_clipx1 && y >= _g_clipy0 && y <= _g_clipy1)
    {
      GLOCK;
      _g_mem[x + y * _g_xsize] = (unsigned char)color;
      GUNLOCK;
    }
}
