/* egaclear.c (emx+gcc) -- Copyright (c) 1994 by Eberhard Mattes */

#include <memory.h>
#include <sys/hw.h>
#include "graph2.h"
#include "ega.h"


void _ega_clear (int color)
{
  OUT3 (color << 8, 0x0f01, 0xff08);
  memset (_g_mem, 0, (_g_xsize / 8) * _g_ysize);
  OUT2 (0xff08, 0x0001);
}
