/* gvgapal.c (emx+gcc) -- Copyright (c) 1987-1998 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#define INCL_VIO
#include <os2emx.h>
#include "graph2.h"
#include <sys/hw.h>

static int port_flag = 0;

void g_vgapal (const char *pal, int first, int n, int wait_flag)
{
  if (port_flag == 0)
    {
      if (_portaccess (0x3c8, 0x3c9) == 0 && _portaccess (0x3da, 0x3da) == 0)
        port_flag = 1;
      else
        port_flag = -1;
    }
  if (port_flag == 1 && n >= 1 && first >= 0 && first <= 255
      && first + n <= 256)
    {
      GLOCK;
      if (wait_flag)
        _wait01 (0x3da, 0x08);
      _outp8 (0x3c8, first);
      _outps8dac (0x3c9, pal, 3 * n);
      GUNLOCK;
    }
}
