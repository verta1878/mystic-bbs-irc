/* gvline.c (emx+gcc) -- Copyright (c) 1987-1994 by Eberhard Mattes */

#include <stdlib.h>
#include <graph.h>
#include "graph2.h"


void _no_vline (unsigned x, unsigned y, unsigned n, int color)
{
}


static void (*_j_vline) (unsigned x, unsigned y, unsigned n, int color)
     = _no_vline;


void g_vline (int x, int y0, int y1, int color)
{
  int f, n;

  if (x >= _g_clipx0 && x <= _g_clipx1)
    {
      f = 1;
      if (y0 < _g_clipy0)
        {
          y0 = _g_clipy0; --f; 
        }
      if (y1 < _g_clipy0)
        {
          if (f == 0)
            return;
          y1 = _g_clipy0;
        }
      f = 1;
      if (y0 > _g_clipy1)
        {
          y0 = _g_clipy1; --f;
        }
      if (y1 > _g_clipy1)
        {
          if (f == 0)
            return;
          y1 = _g_clipy1;
        }
      if (y0 <= y1)
        n = y1 - y0 + 1;
      else
        {
          n = y0 - y1 + 1;
          y0 = y1;
        }
      if (n > 0)
        _j_vline (x, y0, n, color);
    }
}


GPRIM_DEF (vline);
GPRIM_ALL (vline);
