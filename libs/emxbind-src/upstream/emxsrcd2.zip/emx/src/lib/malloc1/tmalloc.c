/* tmalloc.c (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes */

#include <stdlib.h>
#include "malloc1.h"

void *_tmalloc (size_t size)
{
  void *p;

  if (size > MAX_SIZE)
    return NULL;
  if (_malloc_rover == NULL && !_emx_malloc_init ())
    return NULL;
  HEAP_LOCK;
  p = _malloc2 (size, TRUE, TRUE);
  HEAP_UNLOCK;
  return p;
}
