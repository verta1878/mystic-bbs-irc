/* tfree.c (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes */

#include <stdlib.h>
#include "malloc1.h"

void _tfree (void *mem)
{
  if (mem != NULL)
    FREE (mem);
}
