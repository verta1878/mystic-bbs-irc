/* free.c (emx+gcc) -- Copyright (c) 1990-1994 by Eberhard Mattes */

#include <stdlib.h>
#include "malloc1.h"

void free (void *mem)
{
  if (mem != NULL)
    {
      HEAP_LOCK;
      FREE (mem);
      HEAP_UNLOCK;
    }
}
