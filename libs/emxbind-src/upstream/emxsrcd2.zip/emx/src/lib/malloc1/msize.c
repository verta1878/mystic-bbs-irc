/* msize.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdlib.h>
#include "malloc1.h"

size_t _msize (const void *mem)
{
  if (mem == NULL)
    return 0;
  else
    return SIZE (MHEADER (mem)[-1].size);
}
