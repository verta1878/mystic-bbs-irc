/* tcalloc.c (emx+gcc) -- Copyright (c) 1993-1995 by Eberhard Mattes */

#include <stdlib.h>
#include <string.h>

void *_tcalloc (size_t elements, size_t size)
{
  size_t bytes;
  void *p;

  bytes = elements * size;
  if (size != 0 && bytes / size != elements) /* Check for overflow */
    return NULL;
  p = _tmalloc (bytes);
  if (p != NULL)
    memset (p, 0, bytes);
  return p;
}
