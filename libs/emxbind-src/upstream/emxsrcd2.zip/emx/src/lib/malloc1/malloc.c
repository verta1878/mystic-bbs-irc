/* malloc.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdlib.h>
#include "malloc1.h"

void *malloc (size_t size)
{
  void *p;

  if (size > MAX_SIZE)
    return NULL;
  if (_malloc_rover == NULL && !_emx_malloc_init ())
    return NULL;
  HEAP_LOCK;
  p = _malloc2 (size, TRUE, FALSE);
  HEAP_UNLOCK;
  return p;
}


/* See malloc2.c */

void _emx_malloc_magic (void)
{
}
