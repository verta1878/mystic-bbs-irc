/* fgetchar.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdio.h>

int _fgetchar (void)
{
  return getchar ();
}
