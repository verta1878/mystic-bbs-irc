/* fputs.c (emx+gcc) -- Copyright (c) 1990-1993 by Eberhard Mattes */

#include <stdio.h>
#include <string.h>

int fputs (const char *string, FILE *stream)
{
  int len;

  len = strlen (string);
  return (len == 0 || fwrite (string, len, 1, stream) == 1 ? 0 : EOF);
}
