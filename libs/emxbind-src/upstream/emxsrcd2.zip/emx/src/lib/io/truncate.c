/* truncate.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <io.h>
#include <fcntl.h>

int _truncate (char *name, long length)
{
  int handle, result;

  handle = _open (name, O_RDWR);
  if (handle == -1)
    return -1;
  result = _ftruncate (handle, length);
  _close (handle);
  return result;
}
