/* putc.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int _putc_inline (int c, FILE *s)
{
  return (--s->_wcount >= 0 && (c != '\n' || !(s->_flags & _IOLBF))
          ? (unsigned char)(*s->_ptr++ = (char)c)
          : _flush (c, s));
}
