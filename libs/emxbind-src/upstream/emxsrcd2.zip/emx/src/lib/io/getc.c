/* getc.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int _getc_inline (FILE *s)
{
  return (--s->_rcount >= 0
          ? (unsigned char)*s->_ptr++
          : _fill (s));
}
