/* remove.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <errno.h>
#include <emx/syscalls.h>

int remove (const char *name)
{
  return __remove (name);
}
