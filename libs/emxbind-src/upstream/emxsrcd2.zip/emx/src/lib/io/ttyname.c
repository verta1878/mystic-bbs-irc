/* ttyname.c (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes */

#include <unistd.h>
#include <emx/syscalls.h>
#include <emx/thread.h>

char *_ttyname (int handle)
{
#if defined (__MT__)
  struct _thread *tp = _thread ();
#define buf (tp->_th_ttyname)
#else
  static char buf[32];
#endif

  if (__ttyname (handle, buf, sizeof (buf)) == 0)
    return buf;
  else
    return NULL;
}
