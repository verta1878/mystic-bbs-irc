/* fileno.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int fileno (FILE *s)
{
  return s->_handle;
}
