/* fgetpos.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdio.h>

int fgetpos (FILE *stream, fpos_t *pos)
{
  long n;

  if ((n = ftell (stream)) == (long)EOF)
    return EOF;
  pos->_pos = n;
  pos->_reserved1 = 0;
  pos->_mbstate = stream->_mbstate;
  pos->_reserved2 = 0;
  return 0;
}
