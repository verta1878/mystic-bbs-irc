/* rename.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdio.h>
#include <errno.h>
#include <emx/syscalls.h>

int rename (const char *old_name, const char *new_name)
{
  return __rename (old_name, new_name);
}
