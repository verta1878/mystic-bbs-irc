/* flock.c (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes */

#include <sys/file.h>
#include <errno.h>
#include <emx/io.h>

int _flock (int handle, int operation)
{
  if (_fd_flags (handle) == NULL)
    {
      errno = EBADF;
      return -1;
    }
  /*...this is a dummy function...*/
  return 0;
}
