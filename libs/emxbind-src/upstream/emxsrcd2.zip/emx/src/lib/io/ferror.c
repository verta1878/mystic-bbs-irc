/* ferror.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int ferror (FILE *s)
{
  return (s->_flags & _IOERR ? 1 : 0);
}
