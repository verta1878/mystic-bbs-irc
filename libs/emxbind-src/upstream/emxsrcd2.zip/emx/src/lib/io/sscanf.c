/* sscanf.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdio.h>
#include <stdarg.h>
#include <limits.h>
#include <emx/io.h>

int sscanf (const char *buffer, const char *format, ...)
{
  va_list arg_ptr;
  FILE trick;
  struct _file2 trick2;
  int result;

  va_start (arg_ptr, format);
  trick._buffer = (char *)buffer;               /* const -> non-const */
  trick._ptr = (char *)buffer;                  /* const -> non-const */
  trick._rcount = strlen (buffer);
  trick._wcount = 0;
  trick._handle = -1;
  trick._flags = _IOOPEN|_IOSPECIAL|_IOBUFUSER|_IOREAD;
  trick._buf_size = INT_MAX;
  trick._flush = NULL;
  trick._ungetc_count = 0;
  _setdummymore (&trick, &trick2);
  result = _input (&trick, format, arg_ptr);
  va_end (arg_ptr);
  return result;
}
