/* fileleng.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <emx/syscalls.h>

long _filelength (int handle)
{
  long cur, n;

  cur = (long)__lseek (handle, 0L, SEEK_CUR);
  if (cur == -1L)
    return -1;
  n = (long)__lseek (handle, 0L, SEEK_END);
  __lseek (handle, cur, SEEK_SET);
  return n;
}
