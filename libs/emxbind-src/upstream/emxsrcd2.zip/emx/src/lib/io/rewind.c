/* rewind.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <stdio.h>
#include <stdlib.h>
#include <emx/io.h>

void rewind (FILE *stream)
{
  STREAM_LOCK (stream);
  _fflush_nolock (stream);
  _fseek_nolock (stream, 0L, SEEK_SET);
  stream->_flags &= ~_IOERR;
  STREAM_UNLOCK (stream);
}
