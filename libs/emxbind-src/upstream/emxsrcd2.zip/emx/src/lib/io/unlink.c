/* unlink.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <emx/syscalls.h>

int _unlink (const char *name)
{
  return __remove (name);       /* There are no links */
}
