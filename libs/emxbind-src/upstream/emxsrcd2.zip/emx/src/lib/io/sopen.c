/* sopen.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdarg.h>
#include <io.h>
#include <emx/io.h>

int _sopen (const char *name, int oflag, int shflag, ...)
{
  va_list va;
  int h;

  va_start (va, shflag);
  h = _vsopen (name, oflag, shflag, va);
  va_end (va);
  return h;
}
