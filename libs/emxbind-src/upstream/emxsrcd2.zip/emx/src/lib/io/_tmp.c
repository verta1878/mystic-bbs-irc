/* _tmp.c (emx+gcc) */

#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/startup.h>
#include "_tmp.h"

int _tmpidx = IDX_LO;


#if defined (__MT__)

/* This semaphore protects _tmpidx. */

static _rmutex _tmpidx_rmutex;


/* Initialize the semaphore -- this function will be called by
   _startup() via the __crtinit1__ set vector. */

void _init1_tmp (void)
{
  _rmutex_checked_create (&_tmpidx_rmutex, 0);
}

_CRT_INIT1 (_init1_tmp)


void _tmpidx_lock (void)
{
  _rmutex_checked_request (&_tmpidx_rmutex, _FMR_IGNINT);
}

void _tmpidx_unlock (void)
{
  _rmutex_checked_release (&_tmpidx_rmutex);
}

#endif
