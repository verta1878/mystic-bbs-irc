/* feof.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int feof (FILE *s)
{
  return (s->_flags & _IOEOF ? 1 : 0);
}
