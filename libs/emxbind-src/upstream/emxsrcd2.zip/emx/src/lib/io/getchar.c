/* getchar.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int getchar (void)
{
  return getc (stdin);
}
