/* open.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdarg.h>
#include <io.h>
#include <share.h>
#include <emx/io.h>

int _open (const char *name, int oflag, ...)
{
  va_list va;
  int h;

  va_start (va, oflag);
  h = _vsopen (name, oflag, SH_DENYNO, va);
  va_end (va);
  return h;
}
