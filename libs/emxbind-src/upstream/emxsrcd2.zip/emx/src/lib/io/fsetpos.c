/* fsetpos.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdio.h>

int fsetpos (FILE *stream, const fpos_t *pos)
{
  if (fseek (stream, pos->_pos, SEEK_SET) != 0)
    return -1;
  stream->_mbstate = pos->_mbstate;
  return 0;
}
