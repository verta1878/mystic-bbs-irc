/* fgetc.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <stdio.h>
#include <stdlib.h>
#include <emx/io.h>

int fgetc (FILE *stream)
{
  int r;

  STREAM_LOCK (stream);
  r = _getc_inline (stream);
  STREAM_UNLOCK (stream);
  return r;
}
