/* vscanf.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <emx/io.h>

int vscanf (const char *format, va_list arg_ptr)
{
  int r;

  STREAM_LOCK (stdin);
  r = _input (stdin, format, arg_ptr);
  STREAM_UNLOCK (stdin);
  return r;
}
