/* umask.c (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes */

#include <stdlib.h>
#include <emx/syscalls.h>

int _umask (int pmode)
{
  return __umask (pmode);
}
