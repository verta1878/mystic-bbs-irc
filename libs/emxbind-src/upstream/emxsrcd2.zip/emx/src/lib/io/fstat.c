/* fstat.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <time.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <emx/time.h>
#include <emx/syscalls.h>

int _fstat (int handle, struct stat *buffer)
{
  int rc;

  rc = __fstat (handle, buffer);
  if (rc == 0)
    {
      if (!_tzset_flag) _tzset ();
      _loc2gmt (&buffer->st_atime, -1);
      _loc2gmt (&buffer->st_mtime, -1);
      _loc2gmt (&buffer->st_ctime, -1);
    }
  return rc;
}
