/* clearerr.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdio.h>

void clearerr (FILE *stream)
{
  stream->_flags &= ~(_IOERR|_IOEOF);
}
