/* creat.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <io.h>
#include <fcntl.h>

int _creat (const char *name, int pmode)
{
  return _open (name, O_WRONLY|O_TRUNC|O_CREAT, pmode);
}
