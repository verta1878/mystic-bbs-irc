/* getw.c (emx+gcc) -- Copyright (c) 1992-1995 by Kai Uwe Rommel */

#include <stdio.h>

int _getw (FILE *stream)
{
  int x;

  return (fread (&x, sizeof (x), 1, stream) == 1 ? x : EOF);
}
