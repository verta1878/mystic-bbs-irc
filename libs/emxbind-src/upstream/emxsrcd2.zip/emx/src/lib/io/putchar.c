/* putchar.c (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes */

#include <stdio.h>

int putchar (int c)
{
  return putc (c, stdout);
}
