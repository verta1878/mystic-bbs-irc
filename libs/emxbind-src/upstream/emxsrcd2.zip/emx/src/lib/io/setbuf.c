/* setbuf.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdio.h>

int setbuf (FILE *stream, char *buffer)
{
  return setvbuf (stream, buffer, (buffer != NULL ? _IOFBF : _IONBF), BUFSIZ);
}
