/* close.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <errno.h>
#include <emx/io.h>
#include <emx/syscalls.h>

int _close (int handle)
{
  if (_fd_flags (handle) == NULL)
    {
      errno = EBADF;
      return -1;
    }
  return __close (handle);
}
