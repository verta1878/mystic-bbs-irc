/* isatty.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <errno.h>
#include <emx/io.h>

int _isatty (int handle)
{
  int *pflags;

  if ((pflags = _fd_flags (handle)) == NULL)
    {
      errno = EBADF;
      return 0;
    }
  else
    return ((*pflags & F_DEV) ? 1 : 0);
}
