/* fsync.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <emx/syscalls.h>

int _fsync (int handle)
{
  return __fsync (handle);
}
