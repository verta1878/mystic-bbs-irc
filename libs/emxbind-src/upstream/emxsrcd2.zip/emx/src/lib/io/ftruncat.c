/* ftruncat.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <io.h>
#include <errno.h>
#include <emx/io.h>
#include <emx/syscalls.h>

int _ftruncate (int handle, long length)
{
  int *pflags;

  if ((pflags = _fd_flags (handle)) == NULL || (*pflags & F_DEV))
    {
      errno = EBADF;
      return -1;
    }
  return __ftruncate (handle, length);
}
