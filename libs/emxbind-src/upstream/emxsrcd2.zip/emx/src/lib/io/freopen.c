/* freopen.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <stdio.h>
#include <share.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/io.h>

FILE *freopen (const char *fname, const char *mode, FILE *stream)
{
  FILE *result;

  STREAMV_LOCK;
  if (stream->_flags & _IOOPEN)
    fclose (stream);
  result = _fopen (stream, fname, mode, SH_DENYNO, 0);
  STREAMV_UNLOCK;
  return result;
}
