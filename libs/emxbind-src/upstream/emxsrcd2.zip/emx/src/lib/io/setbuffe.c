/* setbuffe.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdio.h>

int _setbuffer (FILE *stream, char *buffer, size_t size)
{
  return setvbuf (stream, buffer, (buffer != NULL ? _IOFBF : _IONBF), size);
}
