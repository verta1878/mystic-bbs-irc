/* tmpnam.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */
/*                       Copyright (c) 1991-1993 by Kolja Elsaesser */

#include <stdio.h>
#include <emx/thread.h>
#include "_tmp.h"


char *tmpnam (char *string)
{
#if defined (__MT__)
  struct _thread *tp = _thread ();
#define tnbuf (tp->_th_tmpnam_buf)
#else
  static char tnbuf[L_tmpnam];
#endif

  if (string == NULL) string = tnbuf;
  if (_tmpidxnam (string) >= 0)
    return string;
  else
    return NULL;
}
