/* emxloadp.c (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes */

#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include <sys/emxload.h>
#include <emx/emxload.h>

int _emxload_prog (const char *name, int seconds)
{
  char buf1[MAXPATHLEN];
  char buf2[MAXPATHLEN];

  if (seconds != _EMXLOAD_INDEFINITE && seconds < 0)
    return -1;
  _strncpy (buf1, name, sizeof (buf1));
  _defext (buf1, "exe");
  if (_path (buf2, buf1) != 0 || _abspath (buf2, buf2, sizeof (buf2)) != 0)
    return -1;
  return _emxload_request (_EMXLOAD_LOAD, buf2, seconds);
}
