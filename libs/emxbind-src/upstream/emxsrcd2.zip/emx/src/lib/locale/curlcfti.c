/* curlcfti.c (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes */

#include <stdlib.h>
#include <emx/locale.h>

struct _lcf_time _cur_lcf_time =
{
  {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"},
  {"January", "February", "March", "April", "May", "June",
   "July", "August", "September", "October", "November", "December"},
  {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"},
  {"Sunday", "Monday", "Tuesday", "Wednesday",
   "Thursday", "Friday", "Saturday"},
  "%a %b %d %H:%M:%S %Y", "%m/%d/%y", "%H:%M:%S",
  "AM", "PM"
};
