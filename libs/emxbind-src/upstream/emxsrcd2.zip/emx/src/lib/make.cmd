@echo off
setlocal
set switchar=-
set gccopt=-pipe %gccopt%
(dmake %1 %2 %3 %4 %5 %6 %7 %8 %9 2>&1) | tee out
endlocal
