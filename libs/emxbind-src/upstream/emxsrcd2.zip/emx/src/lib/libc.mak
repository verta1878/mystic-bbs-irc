#
# /emx/src/lib/libc.mak
#
LIBBASE=c
.INCLUDE: /emx/src/lib/libc0.mak
