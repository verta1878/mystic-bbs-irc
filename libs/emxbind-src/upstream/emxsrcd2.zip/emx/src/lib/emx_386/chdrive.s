/ emx_386/chdrive.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___chdrive

/ int __chdrive (char drive)

        ALIGN

___chdrive:
        movb    1*4(%esp), %dl          /* drive */
        cmpb    $0x61, %dl
        jb      1f
        subb    $0x20, %dl
1:      subb    $0x41, %dl
        SYSCALL (0x0e)
        xorl    %eax, %eax
        EPILOGUE (__chdrive)
