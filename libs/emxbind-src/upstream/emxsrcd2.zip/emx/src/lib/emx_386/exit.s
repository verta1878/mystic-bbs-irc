/ emx_386/exit.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___exit

        ALIGN

___exit:
        SYSCALL (0x4c)
L1:     jmp     L1
