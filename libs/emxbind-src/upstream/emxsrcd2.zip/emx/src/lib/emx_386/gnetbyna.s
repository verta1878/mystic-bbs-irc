/ emx_386/gnetbyna.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getnetbyname

/ int __getnetbyname (const char *name, struct netent **dst)

___getnetbyname:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %ebx         /* dst */
        movb    $0x4d, %al              /* __getnetbyname */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getnetbyname)
