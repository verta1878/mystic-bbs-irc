/ emx_386/dup2.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___dup2

/ int __dup2 (int handle1, int handle2)

        ALIGN

___dup2:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle1 */
        movl    3*4(%esp), %ecx         /* handle2 */
        SYSCALL (0x46)
        popl    %ebx
        SET_EAX
        EPILOGUE (__dup2)
