/ emx_386/ulimit.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ulimit

/ long __ulimit (int cmd, long new_limit)

        ALIGN

___ulimit:
        movb    $2, %al
        movl    1*4(%esp), %ecx         /* cmd */
        movl    2*4(%esp), %edx         /* new_limit */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__ulimit)
