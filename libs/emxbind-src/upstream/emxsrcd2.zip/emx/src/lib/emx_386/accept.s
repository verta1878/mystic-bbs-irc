/ emx_386/accept.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___accept

/ int __accept (int handle, struct sockaddr *addr, int *paddrlen)

___accept:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* addr */
        movl    4*4(%esp), %ecx         /* paddrlen */
        movb    $0x41, %al              /* __accept */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__accept)
