/ emx_386/syserrno.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___syserrno

/ int __syserrno (void)

        ALIGN

___syserrno:
        movb    $0x1f, %al              /* __syserrno */
        SYSCALL (0x7f)
        EPILOGUE (__syserrno)
