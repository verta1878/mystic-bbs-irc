/ emx_386/getsockn.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getsockname

/ int __getsockname (int handle, struct sockaddr *name, int *pnamelen)

___getsockname:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* name */
        movl    4*4(%esp), %ecx         /* pnamelen */
        movb    $0x45, %al              /* __getsockname */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__getsockname)
