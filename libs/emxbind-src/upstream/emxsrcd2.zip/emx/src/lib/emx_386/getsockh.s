/ emx_386/getsockh.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getsockhandle

/ int __getsockhandle (int handle)

___getsockhandle:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movb    $0x3b, %al              /* __getsockhandle */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__getsockhandle)
