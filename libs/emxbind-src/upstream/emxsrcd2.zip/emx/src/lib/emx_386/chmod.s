/ emx_386/chmod.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___chmod

/ int __chmod (char *name, int flag, int attr)

        ALIGN

___chmod:
        movl    1*4(%esp), %edx         /* name */
        movb    2*4(%esp), %al          /* flag */
        movl    3*4(%esp), %ecx         /* attr */
        SYSCALL (0x43)
        jb      1f
        movzwl  %cx, %eax
        jmp     2f

1:      SET_ERRNO (%eax)
        movl    $-1, %eax
2:      EPILOGUE (__chmod)
