/ emx_386/remove.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___remove

/ int __remove (const char *name)

        ALIGN

___remove:
        movl    1*4(%esp), %edx         /* name */
        SYSCALL (0x41)
        SET_0
        EPILOGUE (__remove)
