/ emx_386/cgets.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___cgets

/ void __cgets (char *buffer)

        ALIGN

___cgets:
        movl    1*4(%esp), %edx
        SYSCALL (0x0a)
        EPILOGUE (__cgets)
