/ emx_386/dup.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___dup

/ int __dup (int handle)

        ALIGN

___dup:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        SYSCALL (0x45)
        popl    %ebx
        SET_EAX
        EPILOGUE (__dup)
