/ emx_386/chsize.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___chsize

/ int __chsize (int handle, long length)

        ALIGN

___chsize:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* length */
        movb    $0x18, %al
        SYSCALL (0x7f)
        popl    %ebx
        SET_0
        EPILOGUE (__chsize)
