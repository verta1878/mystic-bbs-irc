/ emx_386/ioctl1.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ioctl1

/ __ioctl1 (int handle, int code)

        ALIGN

___ioctl1:
        pushl   %ebx
        movb    3*4(%esp), %al          /* code */
        movl    2*4(%esp), %ebx         /* handle */
        SYSCALL (0x44)
        popl    %ebx
        jb      Lerror
        movzwl  %dx, %eax
        jmp     Lreturn

Lerror: SET_ERRNO (%eax)
        movl    $-1, %eax
Lreturn:EPILOGUE (__ioctl1)
