/ emx_386/settime.s (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___settime

/ int __settime (const struct timeval *tp)

        ALIGN

___settime:
        movl    1*4(%esp), %edx         /* tp */
        movb    $0x58, %al              /* __settime */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__settime)
