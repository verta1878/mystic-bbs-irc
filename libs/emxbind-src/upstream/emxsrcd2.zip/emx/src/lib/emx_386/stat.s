/ emx_386/stat.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___stat

/ int __stat (const char *name, struct stat *buffer)

        ALIGN

___stat:
        pushl   %edi
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %edi         /* buffer */
        movb    $0x20, %al              /* __stat */
        SYSCALL (0x7f)
        popl    %edi
        SET_ERRNO_ECX
        EPILOGUE (__stat)
