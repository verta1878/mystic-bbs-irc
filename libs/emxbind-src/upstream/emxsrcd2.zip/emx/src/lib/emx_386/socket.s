/ emx_386/socket.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___socket

/ int __socket (int domain, int type, int protocol)

___socket:
        pushl   %ebx
        movl    2*4(%esp), %ecx         /* domain */
        movl    3*4(%esp), %edx         /* type */
        movl    4*4(%esp), %ebx         /* protocol */
        movb    $0x3c, %al              /* __socket */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__socket)
