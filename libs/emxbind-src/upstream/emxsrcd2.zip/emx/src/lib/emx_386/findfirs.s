/ emx_386/findfirs.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___findfirst

/ int __findfirst (const char *name, int attr, struct _find *fp)

        ALIGN

___findfirst:
        pushl   %esi
        movl    2*4(%esp), %edx
        movl    3*4(%esp), %ecx
        movl    4*4(%esp), %esi
        SYSCALL (0x4e)
        popl    %esi
        SET_0
        EPILOGUE (__findfirst)
