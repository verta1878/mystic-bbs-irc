/ emx_386/ftime.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ftime

/ void __ftime (struct timeb *ptr)

        ALIGN

___ftime:
        movl    1*4(%esp), %edx         /* ptr */
        movb    $0x27, %al              /* __ftime */
        SYSCALL (0x7f)
        EPILOGUE (__ftime)
