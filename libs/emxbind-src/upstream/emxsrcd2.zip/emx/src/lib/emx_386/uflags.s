/ emx_386/uflags.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___uflags

/ int __uflags (int mask, int new)

        ALIGN

___uflags:
        movl    1*4(%esp), %ecx         /* mask */
        movl    2*4(%esp), %edx         /* new */
        movb    $0x0f, %al              /* uflags */
        SYSCALL (0x7f)
        EPILOGUE (__uflags)
