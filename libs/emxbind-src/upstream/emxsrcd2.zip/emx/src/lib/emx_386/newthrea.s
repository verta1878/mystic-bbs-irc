/ emx_386/newthrea.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___newthread

/ int __newthread (int tid)

        ALIGN

___newthread:
        movl    1*4(%esp), %edx         /* tid */
        movb    $0x2c, %al              /* __newthread */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__newthread)
