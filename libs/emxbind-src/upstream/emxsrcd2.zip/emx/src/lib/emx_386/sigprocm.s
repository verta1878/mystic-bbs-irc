/ emx_386/sigprocm.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sigprocmask

/ int sigprocmask (int how, const sigset_t *iset, sigset_t *oset)

___sigprocmask:
        pushl   %ebx
        movl    2*4(%esp), %ecx         /* how */
        movl    3*4(%esp), %edx         /* iset */
        movl    4*4(%esp), %ebx         /* oset */
        movb    $0x37, %al              /* __sigprocmask */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__sigprocmask)
