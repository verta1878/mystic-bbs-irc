/ emx_386/sendto.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sendto

/ int __sendto (const struct _sendto *args)

___sendto:
        movl    1*4(%esp), %edx         /* args */
        movb    $0x53, %al              /* __sendto */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__sendto)
