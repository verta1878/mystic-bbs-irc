/ emx_386/os_ver.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___os_version

        ALIGN

___os_version:
        SYSCALL (0x30)
        EPILOGUE (__os_version)
