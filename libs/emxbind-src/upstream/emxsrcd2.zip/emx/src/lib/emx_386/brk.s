/ emx_386/brk.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___brk

/ void *__brk (void *addr)

        ALIGN

___brk:
        movl    1*4(%esp), %edx
        movb    $1, %al
        SYSCALL (0x7f)
        cmpl    $-1, %eax
        jne     1f
        SET_ERRNO ($ENOMEM)
        movl    $-1, %eax
1:      EPILOGUE (__brk)
