/ emx_386/gprotbna.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getprotobyname

/ int __getprotobyname (const char *name, struct protoent **dst)

___getprotobyname:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %ebx         /* dst */
        movb    $0x4b, %al              /* __getprotobyname */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getprotobyname)
