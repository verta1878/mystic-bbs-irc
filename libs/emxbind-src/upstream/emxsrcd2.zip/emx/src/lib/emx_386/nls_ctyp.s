/ emx_386/nls_ctyp.s (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___nls_ctype

/ int __nls_ctype (unsigned char *buf)

        ALIGN

___nls_ctype:
        movl    1*4(%esp), %edx         /* buf */
        movb    $0x5a, %al              /* __nls_ctype */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__nls_ctype)
