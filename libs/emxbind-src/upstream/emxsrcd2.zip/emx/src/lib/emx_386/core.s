/ emx_386/core.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

/ WARNING: emx.dll depends on the stack frame of this function when
/          dumping core
        
#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___core

/ int __core (int handle)

        ALIGN

___core:
        pushl   %ebx
        movl    2*4(%esp), %ebx
        movb    $0x11, %al
        SYSCALL (0x7f)
        popl    %ebx
        SET_0
        EPILOGUE (__core)
