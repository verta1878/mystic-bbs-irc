/ emx_386/execname.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___execname

/ int __execname (char *dst, size_t size)

___execname:
        movl    1*4(%esp), %edx         /* dst */
        movl    2*4(%esp), %ecx         /* size */
        movb    $0x33, %al              /* execname */
        SYSCALL (0x7f)
        EPILOGUE (__execname)
