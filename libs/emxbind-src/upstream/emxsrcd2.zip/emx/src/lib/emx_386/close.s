/ emx_386/close.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___close

/ __close (int handle)

        ALIGN

___close:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        SYSCALL (0x3e)
        popl    %ebx
        SET_0
        EPILOGUE (__close)
