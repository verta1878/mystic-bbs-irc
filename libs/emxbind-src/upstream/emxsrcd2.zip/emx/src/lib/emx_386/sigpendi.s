/ emx_386/sigpendi.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sigpending

/ int sigpending (sigset_t *set)

___sigpending:
        movl    1*4(%esp), %edx         /* set */
        movb    $0x36, %al              /* __sigpending */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__sigpending)
