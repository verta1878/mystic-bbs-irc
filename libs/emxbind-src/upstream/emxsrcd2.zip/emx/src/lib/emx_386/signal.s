/ emx_386/signal.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

/ WARNING: emx.dll depends on the stack frame of this function when
/          dumping core
        
#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___signal

/ void (*__signal (int sig, void (*handler)()))(int sig)

___signal:
        movl    1*4(%esp), %ecx         /* sig */
        movl    2*4(%esp), %edx         /* handler */
        movb    $0x0c, %al              /* signal */
        SYSCALL (0x7f)
        cmpl    $-1, %eax               /* error? */
        jne     Lreturn
        SET_ERRNO ($EINVAL)
        movl    $-1, %eax
Lreturn:EPILOGUE (__signal)
