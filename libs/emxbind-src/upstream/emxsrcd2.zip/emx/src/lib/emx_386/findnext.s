/ emx_386/findnext.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___findnext

/ int __findnext (struct _find *fp)

        ALIGN

___findnext:
        pushl   %esi
        movl    2*4(%esp), %esi
        SYSCALL (0x4f)
        popl    %esi
        SET_0
        EPILOGUE (__findnext)
