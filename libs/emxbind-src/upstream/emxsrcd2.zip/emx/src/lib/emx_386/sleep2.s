/ emx_386/sleep2.s (emx+gcc) -- Copyright (c) 19931-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sleep2

/ unsigned __sleep2 (unsigned millisec)

        ALIGN

___sleep2:
        movl    1*4(%esp), %edx         /* millisec */
        movb    $0x30, %al              /* __sleep2 */
        SYSCALL (0x7f)
        EPILOGUE (__sleep2)
