/ emx_386/setsocko.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___setsockopt

/ int __setsockopt (int handle, int level, int optname, const void *optval,
/                   int optlen)

___setsockopt:
        pushl   %ebx
        pushl   %esi
        pushl   %edi
        movl    4*4(%esp), %ebx         /* handle */
        movl    5*4(%esp), %edx         /* level */
        movl    6*4(%esp), %ecx         /* optname */
        movl    7*4(%esp), %esi         /* optval */
        movl    8*4(%esp), %edi         /* optlen */
        movb    $0x44, %al              /* __setsockopt */
        SYSCALL (0x7f)
        popl    %edi
        popl    %esi
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__setsockopt)
