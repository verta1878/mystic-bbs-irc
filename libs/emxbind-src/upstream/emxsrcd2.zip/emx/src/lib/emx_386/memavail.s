/ emx_386/memavail.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___memavail

/ int __memavail (void)

        ALIGN

___memavail:
        movb    $0x0b, %al
        SYSCALL (0x7f)
        EPILOGUE (__memavail)
