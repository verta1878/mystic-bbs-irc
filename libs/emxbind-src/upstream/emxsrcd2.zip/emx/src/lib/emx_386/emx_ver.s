/ emx_386/emx_ver.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___emx_version

        ALIGN

___emx_version:
        pushl   %ebx
        movb    $0x0a, %al
        SYSCALL (0x7f)
        movl    %ebx, %edx
        popl    %ebx
        EPILOGUE (__emx_version)
