/ emx_386/kill.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___kill

/ int __kill (int pid, int sig)

___kill:
        movl    1*4(%esp), %edx         /* pid */
        movl    2*4(%esp), %ecx         /* sig */
        movb    $0x0d, %al              /* kill */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__kill)
