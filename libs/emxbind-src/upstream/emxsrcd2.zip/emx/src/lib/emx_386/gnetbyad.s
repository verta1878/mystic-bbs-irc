/ emx_386/gnetbyad.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getnetbyaddr

/ int __getnetbyaddr (long net, struct netent **dst)

___getnetbyaddr:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* net */
        movl    3*4(%esp), %ebx         /* dst */
        movb    $0x4e, %al              /* __getnetbyaddr */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getnetbyaddr)
