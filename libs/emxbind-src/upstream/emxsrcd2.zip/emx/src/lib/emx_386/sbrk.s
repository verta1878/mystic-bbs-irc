/ emx_386/sbrk.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sbrk

/ void *__sbrk (int incr)

        ALIGN

___sbrk:
        movl    1*4(%esp), %edx
        movb    $0, %al
        SYSCALL (0x7f)
        cmpl    $-1, %eax
        jne     Lreturn
        SET_ERRNO ($ENOMEM)
        movl    $-1, %eax
Lreturn:EPILOGUE (__sbrk)
