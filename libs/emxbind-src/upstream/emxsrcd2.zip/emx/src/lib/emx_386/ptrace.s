/ emx_386/ptrace.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ptrace

/ int __ptrace (int request, int pid, int addr, int data)

        ALIGN

___ptrace:
        pushl   %ebx
        pushl   %edi
        movl    3*4(%esp), %ebx         /* request */
        movl    4*4(%esp), %edi         /* pid */
        movl    5*4(%esp), %edx         /* addr */
        movl    6*4(%esp), %ecx         /* data */
        movb    $8, %al                 /* ptrace */
        SYSCALL (0x7f)
        popl    %edi
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__ptrace)
