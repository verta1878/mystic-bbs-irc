/ emx_386/endthrea.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___endthread

/ int __endthread (int tid)

        ALIGN

___endthread:
        movl    1*4(%esp), %edx         /* tid */
        movb    $0x2d, %al              /* __endthread */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__endthread)
