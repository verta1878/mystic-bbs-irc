/ emx_386/pipe.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___pipe

/ int __pipe (int *two_handles, int pipe_size)

        ALIGN

___pipe:
        movl    1*4(%esp), %edx         /* two_handles */
        movl    2*4(%esp), %ecx         /* pipe_size */
        movb    $0x1a, %al              /* __pipe */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__pipe)
