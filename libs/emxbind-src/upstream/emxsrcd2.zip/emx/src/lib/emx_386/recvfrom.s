/ emx_386/recvfrom.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___recvfrom

/ int __recvfrom (const struct _recvfrom *args)

___recvfrom:
        movl    1*4(%esp), %edx         /* args */
        movb    $0x52, %al              /* __recvfrom */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__recvfrom)
