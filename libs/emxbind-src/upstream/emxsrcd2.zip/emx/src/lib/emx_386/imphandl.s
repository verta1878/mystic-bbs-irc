/ emx_386/imphandl.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___imphandle

/ int __imphandle (int handle)

___imphandle:
        movl    1*4(%esp), %edx         /* handle */
        movb    $0x39, %al              /* __imphandle */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__imphandle)
