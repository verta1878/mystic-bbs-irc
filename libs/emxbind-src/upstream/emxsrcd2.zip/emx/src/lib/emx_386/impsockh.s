/ emx_386/impsockh.s (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___impsockhandle

/ int __impsockhandle (int handle, int flags)

___impsockhandle:
        movl    1*4(%esp), %edx         /* handle */
        movl    2*4(%esp), %ecx         /* flags */
        movb    $0x54, %al              /* __impsockhandle */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__impsockhandle)
