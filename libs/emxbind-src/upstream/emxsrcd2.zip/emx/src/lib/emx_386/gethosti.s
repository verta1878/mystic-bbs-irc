/ emx_386/gethosti.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___gethostid

/ int __gethostid (int *dst)

___gethostid:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* dst */
        movb    $0x50, %al              /* __gethostid */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__gethostid)
