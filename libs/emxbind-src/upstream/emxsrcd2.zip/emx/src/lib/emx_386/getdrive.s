/ emx_386/getdrive.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getdrive

/ char __getdrive (void)

        ALIGN

___getdrive:
        SYSCALL (0x19)
        addb    $0x41, %al
        movzbl  %al, %eax
        EPILOGUE (__getdrive)
