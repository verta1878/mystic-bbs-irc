/ emx_386/nls_memu.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___nls_memupr

/ void __nls_memupr (unsigned char *buf, size_t size)

        ALIGN

___nls_memupr:
        movl    1*4(%esp), %edx         /* buf */
        movl    2*4(%esp), %ecx         /* size */
        movb    $0x2a, %al              /* __nls_memupr */
        SYSCALL (0x7f)
        EPILOGUE (__nls_memupr)
