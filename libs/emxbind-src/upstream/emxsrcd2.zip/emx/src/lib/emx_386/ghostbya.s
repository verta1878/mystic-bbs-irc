/ emx_386/ghostbya.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___gethostbyaddr

/ int __gethostbyaddr (const char *addr, int len, int type,
/                      struct hostent **dst)

___gethostbyaddr:
        pushl   %ebx
        pushl   %esi
        movl    3*4(%esp), %edx         /* addr */
        movl    4*4(%esp), %ecx         /* len */
        movl    5*4(%esp), %esi         /* type */
        movl    6*4(%esp), %ebx         /* dst */
        movb    $0x48, %al              /* __gethostbyaddr */
        SYSCALL (0x7f)
        popl    %esi
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__gethostbyaddr)
