/ emx_386/umask.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___umask

/ int __umask (int pmode)

        ALIGN

___umask:
        movl    1*4(%esp), %edx         /* pmode */
        movb    $0x28, %al              /* __umask */
        SYSCALL (0x7f)
        EPILOGUE (__umask)
