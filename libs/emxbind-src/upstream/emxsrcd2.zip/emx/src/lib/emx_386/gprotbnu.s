/ emx_386/gprotbnu.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getprotobynumber

/ int __getprotobynumber (int proto, struct protoent **dst)

___getprotobynumber:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* number */
        movl    3*4(%esp), %ebx         /* dst */
        movb    $0x4c, %al              /* __getprotobynumber */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getprotobynumber)
