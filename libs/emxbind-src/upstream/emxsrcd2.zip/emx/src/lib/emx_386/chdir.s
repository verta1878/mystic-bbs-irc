/ emx_386/chdir.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___chdir

/ int __chdir (const char *name)

        ALIGN

___chdir:
        movl    1*4(%esp), %edx
        SYSCALL (0x3b)
        SET_0
        EPILOGUE (__chdir)
