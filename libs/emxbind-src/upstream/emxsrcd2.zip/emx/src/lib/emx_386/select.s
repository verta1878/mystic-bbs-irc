/ emx_386/select.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___select

/ void __select (struct _select *args)

        ALIGN

___select:
        movl    1*4(%esp), %edx         /* args */
        movb    $0x1e, %al              /* __select */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__select)
