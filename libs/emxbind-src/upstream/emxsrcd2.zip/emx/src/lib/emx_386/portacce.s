/ emx_386/portacce.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___portaccess

/ int __portaccess (unsigned first, unsigned last)

        ALIGN

___portaccess:
        movl    1*4(%esp), %ecx         /* first */
        movl    2*4(%esp), %edx         /* last */
        movb    $0x12, %al
        SYSCALL (0x7f)
        SET_0
        EPILOGUE (__portaccess)
