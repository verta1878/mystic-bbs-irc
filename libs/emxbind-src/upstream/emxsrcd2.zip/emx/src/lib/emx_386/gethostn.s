/ emx_386/gethostn.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___gethostname

/ int __gethostname (char *name, int len)

___gethostname:
        movl    1*4(%esp), %edx         /* name */
        movl    2*4(%esp), %ecx         /* len */
        movb    $0x4f, %al              /* __gethostname */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__gethostname)
