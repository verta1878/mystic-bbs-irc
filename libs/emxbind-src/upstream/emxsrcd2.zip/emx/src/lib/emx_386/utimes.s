/ emx_386/utimes.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___utimes

/ int __utimes (const char *name, const struct timeval *tvp)

        ALIGN

___utimes:
        pushl   %esi
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %esi         /* tvp */
        movb    $0x24, %al              /* __utimes */
        SYSCALL (0x7f)
        popl    %esi
        SET_ERRNO_ECX
        EPILOGUE (__utimes)
