/ emx_386/pause.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___pause

/ void __pause (void)

        ALIGN

___pause:
        movb    $0x32, %al              /* __pause */
        SYSCALL (0x7f)
        EPILOGUE (__pause)
