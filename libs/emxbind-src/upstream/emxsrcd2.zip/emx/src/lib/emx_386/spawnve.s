/ emx_386/spawnve.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___spawnve

/ int __spawnve (struct _new_proc *np)

        ALIGN

___spawnve:
        movl    1*4(%esp), %edx
        movw    %ds, %cx
        movw    %cx, 12(%edx)           /* arg_sel */
        movw    %cx, 14(%edx)           /* env_sel */
        movw    %cx, 16(%edx)           /* fname_sel */
        movb    $0x06, %al
        SYSCALL (0x7f)
        SET_EAX
        EPILOGUE (__spawnve)
