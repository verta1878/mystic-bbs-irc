/ emx_386/memacces.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___memaccess

/ void * __memaccess (unsigned first, unsigned last, int flag)

        ALIGN

___memaccess:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* first */
        movl    3*4(%esp), %ecx         /* last */
        movl    4*4(%esp), %edx         /* flag */
        movb    $0x13, %al
        SYSCALL (0x7f)
        popl    %ebx
        jnb     Lreturn
        SET_ERRNO (%eax)
        xorl    %eax, %eax              /* NULL */
Lreturn:EPILOGUE (__memaccess)
