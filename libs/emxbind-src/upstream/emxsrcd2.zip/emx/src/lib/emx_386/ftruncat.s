/ emx_386/ftruncat.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ftruncate

/ int __ftruncate (int handle, long length)

        ALIGN

___ftruncate:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* length */
        movb    $0x25, %al
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__ftruncate)
