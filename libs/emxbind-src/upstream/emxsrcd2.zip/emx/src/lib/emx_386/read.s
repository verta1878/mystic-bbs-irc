/ emx_386/read.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___read

/ __read (int handle, void *buf, size_t nbyte)

        ALIGN

___read:
        pushl   %ebx
        movl    4*4(%esp), %ecx         /* nbyte */
        movl    3*4(%esp), %edx         /* buf */
        movl    2*4(%esp), %ebx         /* handle */
        SYSCALL (0x3f)
        popl    %ebx
        SET_EAX
        EPILOGUE (__read)
