/ emx_386/read_kbd.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___read_kbd

/ int __read_kbd (int echo, int wait, int sig)

        ALIGN

___read_kbd:
        xorl    %edx, %edx
        cmpl    $0, 1*4(%esp)           /* echo */
        je      1f
        orl     $1, %edx
1:      cmpl    $0, 2*4(%esp)           /* wait */
        je      2f
        orl     $2, %edx
2:      cmpl    $0, 3*4(%esp)           /* sig */
        je      3f
        orl     $4, %edx
3:      movb    $0x2f, %al              /* __read_kbd */
        SYSCALL (0x7f)
        EPILOGUE (__read_kbd)
