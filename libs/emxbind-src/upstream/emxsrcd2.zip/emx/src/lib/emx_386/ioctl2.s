/ emx_386/ioctl2.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ioctl2

/ int __ioctl2 (int handle, int request, void *arg)

        ALIGN

___ioctl2:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %ecx         /* request */
        movl    4*4(%esp), %edx         /* arg */
        movb    $0x14, %al              /* ioctl2 */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__ioctl2)
