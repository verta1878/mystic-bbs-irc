/ emx_386/getppid.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getppid

/ int __getppid (void)

        ALIGN

___getppid:
        movb    $0x29, %al
        SYSCALL (0x7f)
        EPILOGUE (__getppid)
