/ emx_386/swchar.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___swchar

/ int __swchar (int flag, int new)

        ALIGN

___swchar:
        movb    1*4(%esp), %al          /* flag */
        movb    2*4(%esp), %dl          /* new */
        SYSCALL (0x37)
        movzbl  %al, %eax
        movb    %dl, %ah
        EPILOGUE (__swchar)
