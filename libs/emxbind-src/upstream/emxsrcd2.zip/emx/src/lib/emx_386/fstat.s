/ emx_386/fstat.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___fstat

/ int __fstat (int handle, struct stat *buffer)

        ALIGN

___fstat:
        pushl   %edi
        pushl   %ebx
        movl    3*4(%esp), %ebx         /* handle */
        movl    4*4(%esp), %edi         /* buffer */
        movb    $0x21, %al              /* __fstat */
        SYSCALL (0x7f)
        popl    %ebx
        popl    %edi
        SET_ERRNO_ECX
        EPILOGUE (__fstat)
