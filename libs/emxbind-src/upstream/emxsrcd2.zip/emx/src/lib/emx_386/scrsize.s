/ emx_386/scrsize.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___scrsize

/ void __scrsize (int *dst)

        ALIGN

___scrsize:
        movl    1*4(%esp), %edx         /* dst */
        movb    $0x1d, %al              /* __scrsize */
        SYSCALL (0x7f)
        EPILOGUE (__scrsize)
