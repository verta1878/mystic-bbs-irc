/ emx_386/getsocko.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getsockopt

/ int __getsockopt (int handle, int level, int optname, void *optval,
/                   int *poptlen)

___getsockopt:
        pushl   %ebx
        pushl   %esi
        pushl   %edi
        movl    4*4(%esp), %ebx         /* handle */
        movl    5*4(%esp), %edx         /* level */
        movl    6*4(%esp), %ecx         /* optname */
        movl    7*4(%esp), %esi         /* optval */
        movl    8*4(%esp), %edi         /* poptlen */
        movb    $0x43, %al              /* __getsockopt */
        SYSCALL (0x7f)
        popl    %edi
        popl    %esi
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__getsockopt)
