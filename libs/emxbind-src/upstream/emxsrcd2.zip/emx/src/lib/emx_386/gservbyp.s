/ emx_386/gservbyp.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getservbyport

/ int __getservbyport (int port, const char *proto, struct servent **dst)

___getservbyport:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* port */
        movl    3*4(%esp), %ecx         /* proto */
        movl    4*4(%esp), %ebx         /* dst */
        movb    $0x4a, %al              /* __getservbyport */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getservbyport)
