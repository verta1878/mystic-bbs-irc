/ emx_386/ghostbyn.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___gethostbyname

/ int __gethostbyname (const char *name, struct hostent **dst)

___gethostbyname:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %ebx         /* dst */
        movb    $0x47, %al              /* __gethostbyname */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__gethostbyname)
