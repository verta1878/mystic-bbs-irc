/ emx_386/sigactio.s (emx+gcc) -- Copyright (c) 1994 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sigaction

/ int __sigaction (int sig, const struct sigaction *iact,
/                  struct sigaction *oact)

___sigaction:
        pushl   %ebx
        movl    2*4(%esp), %ecx         /* sig */
        movl    3*4(%esp), %edx         /* iact */
        movl    4*4(%esp), %ebx         /* oact */
        movb    $0x35, %al              /* __sigaction */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__sigaction)
