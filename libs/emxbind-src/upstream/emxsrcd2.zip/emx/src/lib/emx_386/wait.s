/ emx_386/wait.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___wait

/ int __wait (int *status)
/
/ note: do not call with status == NULL!

        ALIGN

___wait:
        pushl   %ebx
        movb    $9, %al
        SYSCALL (0x7f)
        movl    2*4(%esp), %ebx
        movl    %edx, (%ebx)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__wait)
