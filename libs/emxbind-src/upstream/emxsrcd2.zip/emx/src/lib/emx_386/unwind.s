/ emx_386/unwind.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___unwind2

/ void __unwind2 (void *xcpt_reg_ptr)

        ALIGN

___unwind2:
        movl    1*4(%esp), %edx         /* xcpt_reg_ptr */
        movb    $0x31, %al              /* __unwind2 */
        SYSCALL (0x7f)
        EPILOGUE (__unwind2)
