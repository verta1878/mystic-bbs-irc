/ emx_386/alarm.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___alarm

/ unsigned __alarm (unsigned sec)

        ALIGN

___alarm:
        movl    1*4(%esp), %edx
        movb    $0x15, %al
        SYSCALL (0x7f)
        EPILOGUE (__alarm)
