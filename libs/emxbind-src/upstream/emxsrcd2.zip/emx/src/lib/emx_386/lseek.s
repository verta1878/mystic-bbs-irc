/ emx_386/lseek.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___lseek

/ __lseek (int handle, long offset, int origin)

        ALIGN

___lseek:
        pushl   %ebx
        movb    4*4(%esp), %al          /* origin */
        movl    3*4(%esp), %edx         /* offset */
        movl    2*4(%esp), %ebx         /* handle */
        SYSCALL (0x42)
        popl    %ebx
        SET_EAX
        EPILOGUE (__lseek)
