/ emx_386/profil.s (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___profil

/ int __profil (const struct _profil *p)

        ALIGN

___profil:
        movl    1*4(%esp), %edx         /* p */
        movb    $0x59, %al              /* __profil */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__profil)
