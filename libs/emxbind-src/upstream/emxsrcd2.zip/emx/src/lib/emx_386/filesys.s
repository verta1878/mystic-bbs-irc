/ emx_386/filesys.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___filesys

/ int __filesys (const char *drive, char *name, size_t size)

        ALIGN

___filesys:
        pushl   %edi
        movl    2*4(%esp), %edx         /* drive */
        movl    3*4(%esp), %edi         /* name */
        movl    4*4(%esp), %ecx         /* size */
        movb    $0x23, %al              /* __filesys */
        SYSCALL (0x7f)
        popl    %edi
        SET_ERRNO_ECX
        EPILOGUE (__filesys)
