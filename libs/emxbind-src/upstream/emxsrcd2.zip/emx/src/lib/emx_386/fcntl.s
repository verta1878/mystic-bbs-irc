/ emx_386/fcntl.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___fcntl

/ int __fcntl (int handle, int request, int arg)

        ALIGN

___fcntl:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %ecx         /* request */
        movl    4*4(%esp), %edx         /* arg */
        movb    $0x19, %al              /* fcntl */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__fcntl)
