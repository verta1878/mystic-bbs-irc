/ emx_386/waitpid.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___waitpid

/ int __waitpid (int pid, int *status, int options)
/
/ note: do not call with status == NULL!

        ALIGN

___waitpid:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* pid */
        movl    4*4(%esp), %ecx         /* options */
        movb    $0x2e, %al
        SYSCALL (0x7f)
        movl    3*4(%esp), %ebx         /* status */
        movl    %edx, (%ebx)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__waitpid)
