/ emx_386/sleep.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sleep

/ unsigned __sleep (unsigned sec)

        ALIGN

___sleep:
        movl    1*4(%esp), %edx         /* sec */
        movb    $0x17, %al              /* __sleep */
        SYSCALL (0x7f)
        EPILOGUE (__sleep)
