/ emx_386/mkdir.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___mkdir

/ int __mkdir (const char *name)

        ALIGN

___mkdir:
        movl    1*4(%esp), %edx
        SYSCALL (0x39)
        SET_0
        EPILOGUE (__mkdir)
