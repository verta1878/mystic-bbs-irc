/ emx_386/bind.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___bind

/ int __bind (int handle, struct sockaddr *addr, int addrlen)

___bind:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* addr */
        movl    4*4(%esp), %ecx         /* addrlen */
        movb    $0x3d, %al              /* __bind */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__bind)
