/ emx_386/recv.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___recv

/ int __recv (int handle, void *buf, int len, unsigned flags)

___recv:
        pushl   %ebx
        pushl   %esi
        movl    3*4(%esp), %ebx         /* handle */
        movl    4*4(%esp), %edx         /* buf */
        movl    5*4(%esp), %ecx         /* len */
        movl    6*4(%esp), %esi         /* flags */
        movb    $0x3f, %al              /* __recv */
        SYSCALL (0x7f)
        popl    %esi
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__recv)
