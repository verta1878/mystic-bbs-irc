/ emx_386/initthre.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___initthread

/ int __initthread (void *preg)

        ALIGN

___initthread:
        movl    1*4(%esp), %edx         /* preg */
        movb    $0x34, %al              /* __initthread */
        SYSCALL (0x7f)
        EPILOGUE (__initthread)
