/ emx_386/gservbyn.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getservbyname

/ int __getservbyname (const char *name, const char *proto,
/                      struct servent **dst)

___getservbyname:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* name */
        movl    3*4(%esp), %ecx         /* proto */
        movl    4*4(%esp), %ebx         /* dst */
        movb    $0x49, %al              /* __getservbyname */
        SYSCALL (0x7f)
        popl    %ebx
        EPILOGUE (__getservbyname)
