/ emx_386/getpid.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___getpid

/ int __getpid (void)

        ALIGN

___getpid:
        movb    $5, %al
        SYSCALL (0x7f)
        EPILOGUE (__getpid)
