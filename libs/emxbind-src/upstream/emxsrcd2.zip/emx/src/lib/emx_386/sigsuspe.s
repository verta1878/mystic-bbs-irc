/ emx_386/sigsuspe.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___sigsuspend

/ int sigsuspend (const sigset_t *mask)

___sigsuspend:
        movl    1*4(%esp), %edx         /* mask */
        movb    $0x38, %al              /* __sigsuspend */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__sigsuspend)
