/ emx_386/fsync.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___fsync

/ int __fsync (int handle)

        ALIGN

___fsync:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movb    $0x1b, %al              /* __fsync */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__fsync)
