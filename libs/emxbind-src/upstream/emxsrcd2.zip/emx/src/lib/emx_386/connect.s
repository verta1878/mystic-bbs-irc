/ emx_386/connect.s (emx+gcc) -- Copyright (c) 1994-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___connect

/ int __connect (int handle, struct sockaddr *addr, int addrlen)

___connect:
        pushl   %ebx
        movl    2*4(%esp), %ebx         /* handle */
        movl    3*4(%esp), %edx         /* addr */
        movl    4*4(%esp), %ecx         /* addrlen */
        movb    $0x42, %al              /* __connect */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__connect)
