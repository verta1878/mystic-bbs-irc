/ emx_386/clock.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___clock

/ long long __clock (void)

        ALIGN

___clock:
        movb    $0x26, %al              /* __clock */
        SYSCALL (0x7f)
        EPILOGUE (__clock)
