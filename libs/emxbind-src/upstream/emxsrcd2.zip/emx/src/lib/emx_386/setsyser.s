/ emx_386/setsyser.s (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___setsyserrno

/ int __setsyserrno (int errcode)

        ALIGN

___setsyserrno:
        movl    1*4(%esp), %edx         /* errcode */
        movb    $0x5b, %al              /* __setsyserrno */
        SYSCALL (0x7f)
        EPILOGUE (__setsyserrno)
