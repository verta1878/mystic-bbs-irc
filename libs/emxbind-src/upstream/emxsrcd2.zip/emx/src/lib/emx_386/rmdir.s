/ emx_386/rmdir.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___rmdir

/ int __rmdir (const char *name)

        ALIGN

___rmdir:
        movl    1*4(%esp), %edx
        SYSCALL (0x3a)
        SET_0
        EPILOGUE (__rmdir)
