/ emx_386/rename.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___rename

/ int __rename (const char *old_name, const char *new_name)

        ALIGN

___rename:
        pushl   %edi
        movl    2*4(%esp), %edx         /* old_name */
        movl    3*4(%esp), %edi         /* new_name */
        SYSCALL (0x56)
        popl    %edi
        SET_0
        EPILOGUE (__rename)
