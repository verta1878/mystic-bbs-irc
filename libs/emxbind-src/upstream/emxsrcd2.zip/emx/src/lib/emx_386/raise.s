/ emx_386/raise.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

/ WARNING: emx.dll depends on the stack frame of this function when
/          dumping core

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___raise

/ int __raise (int sig)

        ALIGN

___raise:
        movl    1*4(%esp), %ecx         /* sig */
        movb    $0x0e, %al              /* raise */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__raise)
