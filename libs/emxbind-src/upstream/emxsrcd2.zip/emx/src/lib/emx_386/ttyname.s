/ emx_386/ttyname.s (emx+gcc) -- Copyright (c) 1995-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___ttyname

/ int __ttyname (int handle, char *buf, size_t buf_size)

        ALIGN

___ttyname:
        pushl   %edi
        movl    2*4(%esp), %edx         /* handle */
        movl    3*4(%esp), %edi         /* buf */
        movl    4*4(%esp), %ecx         /* buf_size */
        movb    $0x57, %al              /* __ttyname */
        SYSCALL (0x7f)
        popl    %edi
        SET_ERRNO_ECX
        EPILOGUE (__ttyname)
