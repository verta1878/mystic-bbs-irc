/ emx_386/fork.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___fork

/ int __fork (void)

        ALIGN

___fork:
        movb    $0x1c, %al              /* __fork */
        SYSCALL (0x7f)
        SET_ERRNO_ECX
        EPILOGUE (__fork)
