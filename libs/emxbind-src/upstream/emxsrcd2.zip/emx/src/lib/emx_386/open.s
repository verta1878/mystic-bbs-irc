/ emx_386/open.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>
#include "syscalls.h"

        .globl  ___open

/ __open (char *path, int flags, unsigned long size)

        ALIGN

___open:
        pushl   %ebx
        movl    2*4(%esp), %edx         /* path */
        movl    3*4(%esp), %ecx         /* flags */
        movl    4*4(%esp), %ebx         /* size */
        movb    $0x2b, %al              /* __open */
        SYSCALL (0x7f)
        popl    %ebx
        SET_ERRNO_ECX
        EPILOGUE (__open)
