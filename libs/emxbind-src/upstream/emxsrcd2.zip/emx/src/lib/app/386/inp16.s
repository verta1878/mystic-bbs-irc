/ inp16.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__inp16
	ALIGN
__inp16:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        movl    1*4(%esp), %edx
        inw     %dx, %ax
        movzwl  %ax, %eax
        EPILOGUE(_inp16)

2:	.long	1, 1b+1, __os2_emxio, 3
	.stabs  "__os2dll", 23, 0, 0, 2b
