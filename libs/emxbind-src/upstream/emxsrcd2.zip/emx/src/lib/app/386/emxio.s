/ emxio.s (emx+gcc)

        .globl  __os2_emxio

        .text

__os2_emxio:
        .asciz  "EMXIO"
