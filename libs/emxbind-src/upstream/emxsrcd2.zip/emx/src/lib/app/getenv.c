/* getenv.c (emx+gcc) -- Copyright (c) 1990-1995 by Eberhard Mattes */

#include <stdlib.h>
#include <string.h>

char *getenv (const char *name)
{
  int len;
  char **p;

  if (name == NULL || _environ == NULL)
    return NULL;
  len = strlen (name);
  for (p = _environ; *p != NULL; ++p)
    if (strncmp (*p, name, len) == 0 && (*p)[len] == '=')
      return *p + len + 1;
  return NULL;
}
