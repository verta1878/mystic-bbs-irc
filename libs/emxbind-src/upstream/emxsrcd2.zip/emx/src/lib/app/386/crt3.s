/ crt3.s (emx+gcc) -- Copyright (c) 1994 by Eberhard Mattes

/ This module is used by the following types of executables:
/
/ - Statically linked application programs

        .globl  __cdll_flag

        .data

__cdll_flag:    .byte 0
