/ outps8da.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__outps8dac
	ALIGN
__outps8dac:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %esi
        movl    2*4(%esp), %edx                 /* port */
        movl    3*4(%esp), %esi                 /* src */
        movl    4*4(%esp), %ecx                 /* count */
        ALIGN
2:      movb    (%esi), %al
        outb    %al, %dx
        incl    %esi
        nop
        loop    2b
        popl    %esi
        EPILOGUE(_outps8dac)

2:	.long	1, 1b+1, __os2_emxio, 18
	.stabs  "__os2dll", 23, 0, 0, 2b
