/ inp32.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__inp32
	ALIGN
__inp32:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        movl    1*4(%esp), %edx
        inl     %dx, %eax
        EPILOGUE(_inp32)

2:	.long	1, 1b+1, __os2_emxio, 5
	.stabs  "__os2dll", 23, 0, 0, 2b
