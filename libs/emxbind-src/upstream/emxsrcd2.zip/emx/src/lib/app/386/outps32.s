/ outps32.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__outps32
	ALIGN
__outps32:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %esi
        movl    2*4(%esp), %edx                 /* port */
        movl    3*4(%esp), %esi                 /* src */
        movl    4*4(%esp), %ecx                 /* count */
        rep
        outsl
        popl    %esi
        EPILOGUE(_outps32)

2:	.long	1, 1b+1, __os2_emxio, 13
	.stabs  "__os2dll", 23, 0, 0, 2b
