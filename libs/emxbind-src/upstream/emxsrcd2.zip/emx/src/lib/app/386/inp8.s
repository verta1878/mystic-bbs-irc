/ inp8.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__inp8
	ALIGN
__inp8:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        movl    1*4(%esp), %edx
        inb     %dx, %al
        movzbl  %al, %eax
        EPILOGUE(_inp8)

2:	.long	1, 1b+1, __os2_emxio, 1
	.stabs  "__os2dll", 23, 0, 0, 2b
