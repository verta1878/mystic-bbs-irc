/ crt2.s (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes

#include <emx/asm386.h>

/ This module is used by the following types of executables:
/
/ - Statically linked application programs
/ - Custom C runtime DLLs

        .globl  __entry1
        .globl  __environ
        .globl  __org_environ

        .text

__entry1:
        popl    %esi
        cld
        xorl    %ebp, %ebp      /* End of stack frames */
        leal    (%esp), %edi    /* argv[] */
        movl    %edi, __environ
        movl    %edi, __org_environ
        pushl   %edi            /* envp */
        call    L_ptr_tbl
        pushl   %edi            /* argv */
        call    L_ptr_tbl
        pushl   %ecx            /* argc */
        EPILOGUE_NO_RET(_entry1)
        jmp     *%esi

L_ptr_tbl:
        xorl    %eax, %eax
        movl    $-1, %ecx
1:      incl    %ecx
        scasl
        jne     1b
        ret

        .data

        .comm   __environ, 4
        .comm   __org_environ, 4
