/ outp8.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__outp8
	ALIGN
__outp8:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        movl    1*4(%esp), %edx
        movl    2*4(%esp), %eax
        outb    %al, %dx
        EPILOGUE(_outp8)

2:	.long	1, 1b+1, __os2_emxio, 2
	.stabs  "__os2dll", 23, 0, 0, 2b
