/ outpt.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__outpt
	ALIGN
__outpt:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %esi
        movl    2*4(%esp), %esi                 /* table */
        ALIGN
3:      movl    0*4(%esi), %ecx
        jecxz   9f
        movl    1*4(%esi), %edx
        movl    2*4(%esi), %eax
        addl    $3*4, %esi
        orl     %eax, %eax
        jz      3f
        decl    %eax
        jz      4f
        decl    %eax
        jnz     9f
        rep
        outsl
        jmp     3b

        ALIGN
3:      rep
        outsb
        jmp     3b

        ALIGN
4:      rep
        outsw
        jmp     3b

        ALIGN
9:      popl    %esi
        EPILOGUE(_outpt)

2:	.long	1, 1b+1, __os2_emxio, 9
L1:	.asciz	"emxio"
	.stabs  "__os2dll", 23, 0, 0, 2b
