/* iodata.c (emx+gcc) -- Copyright (c) 1990-1996 by Eberhard Mattes */

#include <fcntl.h>
#include <emx/io.h>

/* The following variables are used for backward compatibility with
   existing libraries (-Zcrtdll -lsocket!).  See also io/_fd.c,
   app/stdio.c, and startup/startup.c. */

int _files[_NFILES];
int _lookahead[_NFILES];
const int _nfiles = _NFILES;

struct fdvec _fdvec_head = {_files, _lookahead, NULL, _NFILES};

int _io_ninherit = 40;
