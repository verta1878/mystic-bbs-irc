/ wait1.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__wait1
	ALIGN
__wait1:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        movl    1*4(%esp), %edx
        movb    2*4(%esp), %cl
        ALIGN
4:      inb     %dx, %al
        testb   %cl, %al
        jz      4b
        EPILOGUE(_wait1)

2:	.long	1, 1b+1, __os2_emxio, 17
	.stabs  "__os2dll", 23, 0, 0, 2b
