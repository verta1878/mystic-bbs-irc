/ outps16.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__outps16
	ALIGN
__outps16:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %esi
        movl    2*4(%esp), %edx                 /* port */
        movl    3*4(%esp), %esi                 /* src */
        movl    4*4(%esp), %ecx                 /* count */
        rep
        outsw
        popl    %esi
        EPILOGUE(_outps16)

2:	.long	1, 1b+1, __os2_emxio, 11
	.stabs  "__os2dll", 23, 0, 0, 2b
