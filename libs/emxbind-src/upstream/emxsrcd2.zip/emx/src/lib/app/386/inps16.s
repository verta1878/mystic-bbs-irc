/ inps16.s (emx+gcc) -- Copyright (c) 1993-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__inps16
	ALIGN
__inps16:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %edi
        movl    2*4(%esp), %edx                 /* port */
        movl    3*4(%esp), %edi                 /* dst */
        movl    4*4(%esp), %ecx                 /* count */
        rep
        insw
        popl    %edi
        EPILOGUE(_inps16)

2:	.long	1, 1b+1, __os2_emxio, 10
	.stabs  "__os2dll", 23, 0, 0, 2b
