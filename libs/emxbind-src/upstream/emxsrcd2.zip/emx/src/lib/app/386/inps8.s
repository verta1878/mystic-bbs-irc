/ inps8.s (emx+gcc) -- Copyright (c) 1992-1996 by Eberhard Mattes

#include <emx/asm386.h>

	.text

	.globl	__inps8
	ALIGN
__inps8:
        PROFILE_NOFRAME
1:	.byte   0xe9
        .long   0
        pushl   %edi
        movl    2*4(%esp), %edx                 /* port */
        movl    3*4(%esp), %edi                 /* dst */
        movl    4*4(%esp), %ecx                 /* count */
        rep
        insb
        popl    %edi
        EPILOGUE(_inps8)

2:	.long	1, 1b+1, __os2_emxio, 7
	.stabs  "__os2dll", 23, 0, 0, 2b
