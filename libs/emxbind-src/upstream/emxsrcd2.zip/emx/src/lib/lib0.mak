#
# /emx/src/lib/lib0.mak
#
GCC=gcc -O2 -Wall -mprobe -fstack-check -mepilogue -DNDEBUG $(LIBC_CCFLAGS) $(MT_CCFLAGS)
AR=ar
I=/emx/include/
S=/emx/include/sys/
L=\emx\lib\ #
MAP=\emx\etc\ #
FCNTL=$(I)fcntl.h $(S)fcntl.h
PROCESS=$(I)process.h $(S)process.h
SIGNAL=$(I)signal.h $(S)signal.h
ERRNO=$(I)errno.h $(S)errno.h
BUILTIN=$(S)builtin.h $(I)$(CPU)/builtin.h
FMUTEX=$(BUILTIN) $(S)fmutex.h
RMUTEX=$(FMUTEX) $(S)rmutex.h
LIBCDLL=/emx/src/lib/cdll/
ASM386H=$(I)emx/asm386.h

PASSDOWN=CPU=$(CPU) DELOPT=$(DELOPT)

.SUFFIXES: .c .imp .o .obj .s

.IF $(OMF)
.c.obj:
	$(GCC) -c -Zomf $<

.s.obj:
	$(GCC) -c -Zomf -x assembler-with-cpp -I. -I../$(CPU) $<
.ELSE
.c.o:
	$(GCC) -c $<

.s.o:
	$(GCC) -c -x assembler-with-cpp -I. -I../$(CPU) $<
.END
