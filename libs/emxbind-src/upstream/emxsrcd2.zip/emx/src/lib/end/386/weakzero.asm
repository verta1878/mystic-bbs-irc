; weakzero.asm (emx+gcc) -- Copyright (c) 1998 by Eberhard Mattes

                .386

                PUBLIC  WEAK$ZERO

WEAK$ZERO       =       0

                END

