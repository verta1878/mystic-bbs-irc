; etext.asm (emx+gcc) -- Copyright (c) 1995 by Eberhard Mattes

                .386

                PUBLIC  _etext

________TEXT    SEGMENT PUBLIC USE32 'CODE'
_etext          LABEL BYTE
________TEXT    ENDS

                END
