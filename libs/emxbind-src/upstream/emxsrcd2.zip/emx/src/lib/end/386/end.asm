; end.asm (emx+gcc) -- Copyright (c) 1995 by Eberhard Mattes

                .386

                PUBLIC  _end

c_common        SEGMENT PUBLIC USE32 'BSS'
c_common        ENDS

________BSS     SEGMENT PUBLIC USE32 'BSS'
_end            LABEL BYTE
________BSS     ENDS

DGROUP          GROUP   c_common, ________BSS

                END
