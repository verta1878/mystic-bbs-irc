; edata.asm (emx+gcc) -- Copyright (c) 1995 by Eberhard Mattes

                .386

                PUBLIC  _edata

________DATA    SEGMENT PUBLIC USE32 'DATA'
_edata          LABEL BYTE
________DATA    ENDS

                END
