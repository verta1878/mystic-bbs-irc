@echo off
setlocal
if "%1"=="st" goto ok_st
if "%1"=="mt" goto ok_mt
:usage
echo Usage: add_libc st
echo        add_libc mt
goto end

:ok_st
set n=st\c.a
goto ok2

:ok_mt
set n=mt\c.a
goto ok2

:ok2
if not "%2"=="" goto usage
ar d \emx\lib\%n% __.SYMDEF
cd conv\%1
ar r \emx\lib\%n% *.o
cd ..\..\ctype\%1
ar r \emx\lib\%n% *.o
cd ..\..\emxload\%1
ar r \emx\lib\%n% *.o
cd ..\..\io\%1
ar r \emx\lib\%n% *.o
cd ..\..\locale\%1
ar r \emx\lib\%n% *.o
cd ..\..\malloc\%1
ar r \emx\lib\%n% *.o
cd ..\..\math\%1
ar r \emx\lib\%n% *.o
cd ..\..\mbyte\%1
ar r \emx\lib\%n% *.o
cd ..\..\misc\%1
ar r \emx\lib\%n% *.o
cd ..\..\nls\%1
ar r \emx\lib\%n% *.o
cd ..\..\process\%1
ar r \emx\lib\%n% *.o
cd ..\..\startup\%1
ar r \emx\lib\%n% *.o
cd ..\..\str\%1
ar r \emx\lib\%n% *.o
cd ..\..\termios\%1
ar r \emx\lib\%n% *.o
cd ..\..\time\%1
ar r \emx\lib\%n% *.o
cd ..\..
ar s \emx\lib\%n%
:end
endlocal
