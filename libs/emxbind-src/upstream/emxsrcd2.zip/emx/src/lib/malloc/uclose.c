/* uclose.c (emx+gcc) -- Copyright (c) 1996-1997 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>

int _uclose (Heap_t h)
{
  if (h->magic != _UM_MAGIC_HEAP
      || h == _um_regular_heap || h == _um_tiled_heap)
    return -1;
#if defined (__MT__)
  _rmutex_close (&h->rsem);
#endif
  return 0;
}
