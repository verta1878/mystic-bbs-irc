/* heapmin.c (emx+gcc) -- Copyright (c) 1996-1998 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>
#include <emx/thread.h>

int _heapmin (void)
{
  _UM_MT_DECL

  if (_UM_DEFAULT_REGULAR_HEAP == NULL)
    _um_init_default_regular_heap ();
  return _uheapmin (_UM_DEFAULT_REGULAR_HEAP);
}
