/* umalloc.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <assert.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>

void *_umalloc (Heap_t h, size_t size)
{
  void *block;
  unsigned flags;

  assert (h->magic == _UM_MAGIC_HEAP);
  if (h->magic != _UM_MAGIC_HEAP)
    return NULL;
  _um_heap_lock (h);
  flags = 0;
  if (h->type & _HEAP_TILED)
    flags |= _UMFI_TILED;
  block = _um_alloc_no_lock (h, size, 4, flags);
  _um_heap_unlock (h);
  return block;
}
