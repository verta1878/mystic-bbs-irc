/* malloc.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>
#include <emx/thread.h>

void *malloc (size_t size)
{
  _UM_MT_DECL

  if (_UM_DEFAULT_REGULAR_HEAP == NULL)
    _um_init_default_regular_heap ();
  return _umalloc (_UM_DEFAULT_REGULAR_HEAP, size);
}

/* See initt.c */

void _emx_tmalloc_magic (void)
{
}
