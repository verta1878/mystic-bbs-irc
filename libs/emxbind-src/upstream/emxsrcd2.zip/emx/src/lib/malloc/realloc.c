/* realloc.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>

void *realloc (void *block, size_t new_size)
{
  if (block == NULL)
    return malloc (new_size);
  else
    return _um_realloc (block, new_size, 4, 0);
}
