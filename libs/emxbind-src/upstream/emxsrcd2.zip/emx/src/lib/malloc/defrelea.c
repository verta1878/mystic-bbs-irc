/* defrelea.c (emx+gcc) -- Copyright (c) 1996 by Eberhard Mattes */

#include <stdlib.h>
#include <stddef.h>
#include <umalloc.h>
#include <sys/builtin.h>        /* For <sys/fmutex.h> */
#include <sys/fmutex.h>         /* For <sys/rmutex.h> */
#include <sys/rmutex.h>
#include <emx/umalloc.h>

void _um_default_release (Heap_t h, void *memory, size_t size)
{
  void *cur;

  cur = _sbrk (0);
  if (_UM_ADD (memory, size) == cur)
    _sbrk (-size);
}
