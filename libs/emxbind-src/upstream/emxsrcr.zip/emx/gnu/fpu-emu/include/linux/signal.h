/* linux/signal.h */

#include <sys/signal.h>
