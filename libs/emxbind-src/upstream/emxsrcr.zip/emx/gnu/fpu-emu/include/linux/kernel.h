/* linux/kernel.h */

#define VERIFY_READ 0
#define VERIFY_WRITE 1

#define printk printf
#define verify_area(TYPE,ADDR,COUNT) 0
